#!/usr/bin/env python3
"""L298N actuator keyboard/PWM test. BCM19=IN1, BCM26=IN2, ENA tied to 5V."""

import argparse
from contextlib import ExitStack
import curses
import signal
import sys
import threading
import time

from gpiozero import PWMOutputDevice
from gpiozero.pins.lgpio import LGPIOFactory


class Actuator:
    TIMEOUT = 0.3
    MAX_BURST = 2.0
    RELEASE = 0.6

    def __init__(self, stack, factory, invert=False):
        self.lock = threading.RLock()
        self.devices = []
        self.direction = self.previous = 0
        self.stopped_at = self.last_input = 0.0
        self.started = None
        self.latched = False
        self.invert = invert
        stack.callback(self.stop)
        for pin in (19, 26):
            device = PWMOutputDevice(pin, initial_value=0, frequency=100, pin_factory=factory)
            self.devices.append(device)
            stack.callback(device.close)
        self.in1, self.in2 = self.devices
        stack.callback(self.stop)

    def stop(self):
        with self.lock:
            for device in self.devices:
                if not device.closed:
                    device.off()
            if self.direction:
                self.previous = self.direction
                self.stopped_at = time.monotonic()
            self.direction = 0

    def tick(self):
        with self.lock:
            now = time.monotonic()
            if self.started is not None and now - self.started >= self.MAX_BURST:
                self.latched = True
                self.stop()
            if now - self.last_input >= self.TIMEOUT:
                self.stop()
            if now - self.last_input >= self.RELEASE:
                self.latched = False
                self.started = None

    def command(self, direction, duty):
        if direction not in (-1, 1) or not 0 < duty <= 1:
            self.stop()
            raise ValueError('Direction must be +/-1 and PWM duty in (0, 1].')
        with self.lock:
            self.tick()
            self.last_input = time.monotonic()
            if self.latched:
                return
            try:
                if direction != self.direction:
                    self.stop()
                    if self.previous and self.previous != direction:
                        time.sleep(max(0, 0.25 - (time.monotonic() - self.stopped_at)))
                    self.direction = direction
                if self.started is None:
                    self.started = time.monotonic()
                active = self.in1 if (direction == 1) != self.invert else self.in2
                active.value = duty
            except BaseException:
                self.stop()
                raise


def run_test(motor, failed, slow=0.6):
    print('No position/current feedback. Keep clear of pinch points and end stops.', flush=True)
    print('Starting in 3 seconds. Ctrl+C stops. UP polarity must be checked visually.', flush=True)
    time.sleep(3)
    legs = [
        ('Short UP', 1, ((0.25, 1.0, 1.0),)),
        ('Short DOWN', -1, ((0.25, 1.0, 1.0),)),
        ('UP: normal -> reduced PWM', 1, ((0.4, 1.0, 1.0), (0.3, 1.0, slow), (0.4, slow, slow))),
        ('DOWN: normal -> reduced PWM', -1, ((0.4, 1.0, 1.0), (0.3, 1.0, slow), (0.4, slow, slow))),
    ]
    for label, direction, stages in legs:
        print(label, flush=True)
        try:
            for seconds, start_duty, end_duty in stages:
                print(f'  PWM {start_duty:.0%} -> {end_duty:.0%}, {seconds:.2f}s', flush=True)
                start = time.monotonic()
                while time.monotonic() - start < seconds:
                    if failed.is_set():
                        raise RuntimeError('Watchdog failed')
                    fraction = min(1.0, (time.monotonic() - start) / seconds)
                    motor.command(direction, start_duty + fraction * (end_duty - start_duty))
                    time.sleep(0.02)
        finally:
            motor.stop()
        print('Stopped for 1 second.', flush=True)
        time.sleep(1)
    print('Sequence complete; movement/speed/return to original position are NOT verified.', flush=True)


def keyboard(screen, motor, failed, duty):
    screen.keypad(True)
    screen.timeout(50)
    curses.set_escdelay(30)
    def render():
        lines = [
            'Linear motor: UP / DOWN. SPACE=stop. Q or Ctrl+C=exit.',
            f'PWM selected: {duty:.0%}. Keys 1=60%, 2=80%, 3=100%.',
            'Changing PWM stops motion; press direction again to resume.',
            'No input 0.3s: stop. Burst limit 2s; release keys 0.6s to reset.',
            'No end-stop/current sensing. Disconnect battery if stalled.',
            'UP polarity is installation-dependent; use --invert if reversed.',
        ]
        screen.erase()
        for row, line in enumerate(lines):
            try:
                screen.addnstr(row, 0, line, max(1, screen.getmaxyx()[1]-1))
            except curses.error:
                pass
        screen.refresh()
    render()
    while not failed.is_set():
        key = screen.getch()
        if key in (ord('q'), ord('Q'), 3, 4):
            break
        if key in (curses.KEY_UP, curses.KEY_DOWN):
            motor.command(1 if key == curses.KEY_UP else -1, duty)
        elif key in (ord('1'), ord('2'), ord('3')):
            motor.stop()
            duty = {ord('1'): 0.6, ord('2'): 0.8, ord('3'): 1.0}[key]
            render()
        elif key != -1:
            motor.stop()
    if failed.is_set():
        raise RuntimeError('Watchdog failed; disconnect motor battery')


def duty_value(value):
    number = float(value)
    if not 0.1 <= number <= 1:
        raise argparse.ArgumentTypeError('PWM duty must be 0.1 to 1.0')
    return number


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--test', action='store_true', help='short motions then normal-to-slow PWM in each direction')
    parser.add_argument('--invert', action='store_true', help='swap logical UP/DOWN')
    parser.add_argument('--duty', type=duty_value, default=1.0, help='initial keyboard duty, default 1.0')
    parser.add_argument('--slow-duty', type=duty_value, default=0.6, help='reduced test PWM, default 0.6')
    parser.add_argument('--simulate', action='store_true', help='virtual GPIO only; never move hardware')
    args = parser.parse_args(argv)
    if args.test and args.slow_duty >= 1:
        parser.error('--slow-duty must be less than 1 for the speed-change test')
    if not args.test and not (sys.stdin.isatty() and sys.stdout.isatty()):
        parser.error('Keyboard mode requires an interactive SSH terminal.')
    def interrupted(signum, frame):
        raise KeyboardInterrupt
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGTSTP):
        signal.signal(sig, interrupted)
    with ExitStack() as stack:
        if args.simulate:
            from gpiozero.pins.mock import MockFactory, MockPWMPin
            factory = MockFactory(pin_class=MockPWMPin)
            print('SIMULATION: no physical GPIO access.', flush=True)
        else:
            factory = LGPIOFactory()
        stack.callback(factory.close)
        motor = Actuator(stack, factory, args.invert)
        done, failed = threading.Event(), threading.Event()
        def watchdog():
            try:
                while not done.wait(0.02):
                    motor.tick()
            except BaseException:
                failed.set()
                motor.stop()
        thread = threading.Thread(target=watchdog, daemon=True)
        if not args.simulate and sys.stdin.isatty():
            input("출력 정지 상태. 모터 전원을 켠 뒤 Enter: ")
        thread.start()
        try:
            if args.test:
                run_test(motor, failed, args.slow_duty)
            else:
                curses.wrapper(keyboard, motor, failed, args.duty)
        finally:
            motor.stop()
            done.set()
            thread.join(timeout=1)
            if not args.simulate and sys.stdin.isatty():
                input("정지. 모터 전원을 끈 뒤 Enter: ")
    print('PWM OFF; GPIO released. Disconnect motor battery after use.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('Stopped by interrupt.', flush=True)
        sys.exit(130)

