#!/usr/bin/env python3
"""Four independent L298N channels. Default: print wiring, never touch GPIO.

Use --run for forward, pivot left, pivot right, reverse, then a final left pivot.
The final pivot drives the left wheels backwards and right wheels forwards for 3 seconds.
Forward is electrical IN1=0, IN2=1;
wheel mounting/polarity must be checked with the wheels raised off the floor.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import math
from pathlib import Path
import signal
import sys
import threading


@dataclass(frozen=True)
class Motor:
    name: str
    in1: int
    in2: int
    enable: int
    physical: tuple[int, int, int]
    reverse: bool = False


# GPIO line numbers, NOT physical header pin numbers.
# Change reverse to True only for a wheel found to rotate backwards.
MOTORS = (
    Motor('왼쪽 앞', 17, 27, 22, (11, 13, 15), True),
    Motor('왼쪽 뒤', 9, 11, 10, (21, 23, 19), True),
    Motor('오른쪽 앞', 3, 4, 2, (5, 7, 3), True),
    Motor('오른쪽 뒤', 5, 6, 13, (29, 31, 33), True),
)
PWM_HZ = 200


def wheel_duties(directions, straight_percent):
    """Return PWM percentages in motor order."""
    if 1 in directions and -1 in directions:
        return tuple(100 if direction == 1 else 50 for direction in directions)
    return (straight_percent,) * len(directions)


def open_rp1(gpio):
    """Read chip metadata only; never guess gpiochip0 versus gpiochip4."""
    failures = []
    for device in sorted(Path('/dev').glob('gpiochip[0-9]*')):
        handle = None
        try:
            handle = gpio.gpiochip_open(int(device.name.removeprefix('gpiochip')))
            info = gpio.gpio_get_chip_info(handle)
            label = info[3]
            if isinstance(label, bytes):
                label = label.decode()
            if label == 'pinctrl-rp1':
                print(f'사용 장치: {device} ({label})', flush=True)
                return handle
        except Exception as exc:
            failures.append(f'{device}: {exc}')
        if handle is not None:
            gpio.gpiochip_close(handle)
    raise RuntimeError('접근 가능한 Pi 5 pinctrl-rp1 GPIO 장치를 찾지 못했습니다. '
                       '권한 또는 실행 환경을 확인하세요.\n' + '\n'.join(failures))


class WheelDrive:
    def __init__(self, gpio, handle, motors=MOTORS):
        self.gpio, self.handle, self.motors = gpio, handle, motors
        self.claimed = []

    def claim(self):
        # Disable EVERY bridge before configuring any direction outputs.
        pins = [m.enable for m in self.motors]
        pins += [p for m in self.motors for p in (m.in1, m.in2)]
        for pin in pins:
            self.gpio.gpio_claim_output(self.handle, pin, 0)
            self.claimed.append(pin)

    def forward(self, duty, seconds, stop):
        self.move((1, 1, 1, 1), duty, seconds, stop)

    def move(self, directions, duty, seconds, stop):
        if len(directions) != len(self.motors) or any(d not in (-1, 1) for d in directions):
            raise ValueError('각 바퀴에 +1 또는 -1 방향이 필요합니다.')
        if stop.is_set():
            return
        try:
            for motor, direction in zip(self.motors, directions):
                positive = (direction == 1) != motor.reverse
                self.gpio.gpio_write(self.handle, motor.in1, int(positive))
                self.gpio.gpio_write(self.handle, motor.in2, int(not positive))
            # All EN lines are LOW before direction changes, including between moves.
            if stop.wait(0.02):
                return
            cycles = max(1, round(seconds * PWM_HZ))
            for motor, wheel_duty in zip(self.motors, wheel_duties(directions, duty)):
                if stop.is_set():
                    return
                result = self.gpio.tx_pwm(self.handle, motor.enable, PWM_HZ, wheel_duty,
                                          pulse_cycles=cycles)
                if result < 0:
                    raise RuntimeError(f'{motor.name}: PWM 시작 실패 ({result})')
            stop.wait(seconds)
        finally:
            errors = self.disable()
            if errors:
                raise RuntimeError('출력 해제 실패: ' + '; '.join(errors))

    def disable(self):
        errors = []
        # Cancel PWM and disable every claimed EN even if an earlier stop fails.
        for motor in self.motors:
            if motor.enable not in self.claimed:
                continue
            for action in (
                lambda m=motor: self.gpio.tx_pwm(self.handle, m.enable, 0, 0),
                lambda m=motor: self.gpio.gpio_write(self.handle, m.enable, 0),
            ):
                try:
                    action()
                except Exception as exc:
                    errors.append(str(exc))
        for motor in self.motors:
            for pin in (motor.in1, motor.in2):
                if pin in self.claimed:
                    try:
                        self.gpio.gpio_write(self.handle, pin, 0)
                    except Exception as exc:
                        errors.append(str(exc))
        return errors

    def close(self):
        errors = self.disable()
        for pin in reversed(self.claimed):
            try:
                self.gpio.gpio_free(self.handle, pin)
            except Exception as exc:
                errors.append(str(exc))
        self.claimed.clear()
        try:
            self.gpio.gpiochip_close(self.handle)
        except Exception as exc:
            errors.append(str(exc))
        return errors


def run_sequence(drive, stop, duty=100, forward_seconds=2, turn_seconds=1,
                 reverse_seconds=2, spin_seconds=3):
    steps = (
        ('전진', (1, 1, 1, 1), forward_seconds),
        ('제자리 좌회전', (-1, -1, 1, 1), turn_seconds),
        ('제자리 우회전', (1, 1, -1, -1), turn_seconds),
        ('후진', (-1, -1, -1, -1), reverse_seconds),
        ('마지막 제자리 회전 (왼쪽 후진 / 오른쪽 전진)', (-1, -1, 1, 1), spin_seconds),
    )
    for index, (name, directions, seconds) in enumerate(steps):
        if stop.is_set():
            break
        left, _, right, _ = wheel_duties(directions, duty)
        print(f'{name}: 왼쪽 PWM {left:g}%, 오른쪽 PWM {right:g}%, {seconds:g}초', flush=True)
        drive.move(directions, duty, seconds, stop)
        if index < len(steps) - 1 and stop.wait(0.5):
            break


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', help='실제 모터 출력 활성화')
    parser.add_argument('--duty', type=float, default=100, help='직진·후진 PWM %% (기본 100, 허용 10~100)')
    parser.add_argument('--seconds', type=float, default=2, help='전진 시간 (기본 2초, 허용 0.1~5)')
    parser.add_argument('--turn-seconds', type=float, default=1, help='좌/우 각각 회전 시간 (기본 1초, 허용 0.1~5)')
    parser.add_argument('--reverse-seconds', type=float, default=2, help='후진 시간 (기본 2초, 허용 0.1~5)')
    parser.add_argument('--spin-seconds', type=float, default=3, help='마지막 왼쪽 후진/오른쪽 전진 시간 (기본 3초, 허용 0.1~5)')
    args = parser.parse_args(argv)
    if not math.isfinite(args.duty) or not 10 <= args.duty <= 100:
        parser.error('--duty는 10~100 사이여야 합니다.')
    for name in ('seconds', 'turn_seconds', 'reverse_seconds', 'spin_seconds'):
        value = getattr(args, name)
        if not math.isfinite(value) or not 0.1 <= value <= 5:
            parser.error(f'--{name.replace("_", "-")}는 0.1~5 사이여야 합니다.')
    for m in MOTORS:
        print(f'{m.name}: GPIO {m.in1}/{m.in2}/{m.enable}, '
              f'물리 핀 {m.physical}, reverse={m.reverse}')
    print(f'계획: 전진 {args.seconds:g}초 → 좌회전 {args.turn_seconds:g}초 → '
          f'우회전 {args.turn_seconds:g}초 → 후진 {args.reverse_seconds:g}초 → '
          f'마지막 왼쪽 후진/오른쪽 전진 {args.spin_seconds:g}초; '
          f'직진·후진 PWM {args.duty:g}%, 회전 시 전진 쪽 100%, 후진 쪽 50%, 동작 사이 출력 해제 0.5초')
    if not args.run:
        print('배선 확인만 수행했습니다. GPIO에 접근하지 않았습니다. 실제 회전: --run')
        return 0
    try:
        import lgpio
    except ImportError:
        print('lgpio가 없습니다. motor_control/setup.sh를 먼저 실행하세요.', file=sys.stderr)
        return 1
    stop = threading.Event()
    old_handlers = {}
    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        old_handlers[signum] = signal.signal(signum, lambda *_: stop.set())
    drive = None
    exit_code = 0
    try:
        drive = WheelDrive(lgpio, open_rp1(lgpio))
        drive.claim()
        if sys.stdin.isatty():
            input("출력 정지 상태. 모터 전원을 켠 뒤 Enter: ")
        print('바퀴를 바닥에서 들어 올려 두세요. 3초 뒤 회전합니다. Ctrl+C로 취소.', flush=True)
        if not stop.wait(3):
            run_sequence(drive, stop, args.duty, args.seconds,
                         args.turn_seconds, args.reverse_seconds, args.spin_seconds)
    except Exception as exc:
        print(f'오류: {exc}', file=sys.stderr)
        exit_code = 1
    finally:
        if drive is not None:
            if len(drive.claimed) == 12 and sys.stdin.isatty():
                try:
                    input("모터 전원을 끈 뒤 Enter: ")
                finally:
                    errors = drive.close()
            else:
                errors = drive.close()
            if errors:
                print('출력 해제 오류: 배터리 스위치를 끄세요. ' + '; '.join(errors), file=sys.stderr)
                exit_code = 1
            else:
                print('PWM 종료, EN LOW, GPIO 해제 완료. 바퀴는 관성으로 잠깐 더 돌 수 있습니다.')
        for signum, handler in old_handlers.items():
            signal.signal(signum, handler)
    return exit_code


if __name__ == '__main__':
    sys.exit(main())

