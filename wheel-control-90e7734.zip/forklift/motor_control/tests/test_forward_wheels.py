from pathlib import Path
from dataclasses import replace
import sys
import threading
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from forward_wheels import MOTORS, WheelDrive, main, run_sequence


class FakeGPIO:
    def __init__(self, fail_claim=None, fail_pwm=None):
        self.events = []
        self.fail_claim, self.fail_pwm = fail_claim, fail_pwm

    def gpio_claim_output(self, handle, pin, level):
        if pin == self.fail_claim:
            raise RuntimeError('line busy')
        self.events.append(('claim', pin, level))

    def gpio_write(self, handle, pin, level):
        self.events.append(('write', pin, level))

    def tx_pwm(self, handle, pin, hz, duty, **kwargs):
        self.events.append(('pwm', pin, hz, duty, kwargs))
        if pin == self.fail_pwm and hz:
            raise RuntimeError('PWM failure')
        return 0

    def gpio_free(self, handle, pin):
        self.events.append(('free', pin))

    def gpiochip_close(self, handle):
        self.events.append(('close',))


class Tests(unittest.TestCase):
    def test_pin_map_is_independent_and_matches_wiring(self):
        self.assertEqual([(m.in1,m.in2,m.enable) for m in MOTORS],
                         [(17,27,22),(9,11,10),(3,4,2),(5,6,13)])
        self.assertEqual(len({p for m in MOTORS for p in (m.in1,m.in2,m.enable)}), 12)

    def test_all_en_low_before_direction_and_bounded_pwm(self):
        gpio = FakeGPIO()
        drive = WheelDrive(gpio, 0)
        drive.claim()
        self.assertEqual(gpio.events[:4], [('claim', m.enable, 0) for m in MOTORS])
        drive.forward(40, 0.01, threading.Event())
        starts = [e for e in gpio.events if e[0]=='pwm' and e[2]>0]
        self.assertEqual(len(starts), 4)
        self.assertTrue(all(e[4]['pulse_cycles']==2 for e in starts))
        self.assertEqual(drive.close(), [])
        self.assertEqual(gpio.events[-1], ('close',))
        for m in MOTORS:
            self.assertIn(('write',m.enable,0),gpio.events)

    def test_partial_claim_failure_never_enables_motors(self):
        gpio = FakeGPIO(fail_claim=MOTORS[1].enable)
        drive = WheelDrive(gpio, 0)
        with self.assertRaises(RuntimeError):
            drive.claim()
        drive.close()
        self.assertFalse(any(e[0]=='pwm' and e[2]>0 for e in gpio.events))
        self.assertIn(('free', MOTORS[0].enable), gpio.events)
        self.assertNotIn(('free', MOTORS[1].enable), gpio.events)

    def test_pwm_start_failure_still_disables_all_claimed_channels(self):
        gpio = FakeGPIO(fail_pwm=MOTORS[1].enable)
        drive = WheelDrive(gpio, 0)
        drive.claim()
        with self.assertRaises(RuntimeError):
            drive.forward(40, 0.01, threading.Event())
        drive.close()
        for m in MOTORS:
            self.assertIn(('write',m.enable,0),gpio.events)

    def test_cancel_does_not_start_pwm(self):
        gpio = FakeGPIO()
        drive = WheelDrive(gpio, 0)
        drive.claim()
        stop = threading.Event()
        stop.set()
        drive.forward(40, 0.01, stop)
        self.assertFalse(any(e[0]=='pwm' for e in gpio.events))
        drive.close()

    def test_default_is_dry_run(self):
        self.assertEqual(main([]), 0)

    def test_sequence_directions_wheel_duties_and_disabled_between_moves(self):
        gpio = FakeGPIO()
        drive = WheelDrive(gpio, 0)
        drive.claim()

        class Stop:
            def is_set(self):
                return False

            def wait(self, duration):
                gpio.events.append(('wait', duration))
                return False

        run_sequence(drive, Stop(), duty=35)
        directions = []
        duties = []
        levels = {}
        enabled = set()
        for event in gpio.events:
            if event[0] == 'write':
                if event[1] in {p for m in MOTORS for p in (m.in1, m.in2)}:
                    self.assertFalse(enabled, 'direction changed with an active EN')
                levels[event[1]] = event[2]
            elif event[0] == 'pwm':
                if event[2] > 0:
                    if event[1] == MOTORS[0].enable:
                        directions.append(tuple(levels[m.in1] for m in MOTORS))
                        duties.append({})
                    duties[-1][event[1]] = event[3]
                    enabled.add(event[1])
                else:
                    enabled.discard(event[1])
            elif event == ('wait', 0.5):
                self.assertFalse(enabled)
                self.assertTrue(all(levels[m.enable] == 0 for m in MOTORS))
        self.assertEqual(directions, [(0,0,0,0), (1,1,0,0), (0,0,1,1), (1,1,1,1), (1,1,0,0)])
        self.assertEqual([tuple(step[m.enable] for m in MOTORS) for step in duties],
                         [(35,35,35,35), (50,50,100,100), (100,100,50,50),
                          (35,35,35,35), (50,50,100,100)])
        self.assertEqual([e[1] for e in gpio.events if e[0]=='wait'],
                         [0.02,2,0.5,0.02,1,0.5,0.02,1,0.5,0.02,2,0.5,0.02,3])
        self.assertFalse(enabled)
        drive.close()

    def test_cancel_during_motion_stops_sequence_and_disables_all(self):
        gpio = FakeGPIO()
        drive = WheelDrive(gpio, 0)
        drive.claim()

        class Stop:
            cancelled = False

            def is_set(self):
                return self.cancelled

            def wait(self, duration):
                if duration == 2:
                    self.cancelled = True
                return self.cancelled

        run_sequence(drive, Stop())
        self.assertEqual(len([e for e in gpio.events if e[0]=='pwm' and e[2]>0]), 4)
        for motor in MOTORS:
            self.assertIn(('write', motor.enable, 0), gpio.events)
        drive.close()

    def test_reverse_setting_applies_to_both_requested_directions(self):
        gpio = FakeGPIO()
        motors = (replace(MOTORS[0], reverse=False), *MOTORS[1:])
        drive = WheelDrive(gpio, 0, motors)
        drive.claim()
        for direction, expected in ((1, 1), (-1, 0)):
            gpio.events.clear()
            drive.move((direction,)*4, 100, 0.001, threading.Event())
            self.assertEqual(gpio.events[0], ('write', motors[0].in1, expected))
            self.assertEqual(gpio.events[1], ('write', motors[0].in2, 1-expected))
        drive.close()


if __name__ == '__main__':
    unittest.main()

