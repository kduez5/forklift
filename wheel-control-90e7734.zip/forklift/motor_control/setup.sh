#!/bin/sh
set -eu
/usr/bin/python3 -c "import gpiozero, lgpio; print('GPIO libraries available')"
