"""노션의 통합 수동 제어 동작 설명을 현재 Pi 배선으로 재구현."""
import argparse
import curses
import signal
import sys
from contextlib import ExitStack
from pathlib import Path
from time import monotonic

from gpiozero import DigitalOutputDevice, PWMOutputDevice
from gpiozero.pins.lgpio import LGPIOFactory

from forward_wheels import MOTORS, wheel_duties
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "mot_linear"))
from linear_control import Actuator

# 순서: 왼쪽 앞, 왼쪽 뒤, 오른쪽 앞, 오른쪽 뒤
MOVES = {"w": (1, 1, 1, 1), "s": (-1, -1, -1, -1),
         "a": (-1, -1, 1, 1), "d": (1, 1, -1, -1)}
ARROWS = {curses.KEY_UP: "w", curses.KEY_DOWN: "s",
          curses.KEY_LEFT: "a", curses.KEY_RIGHT: "d"}


class Wheels:
    def __init__(self, stack, factory):
        self.enables = [stack.enter_context(PWMOutputDevice(
            m.enable, initial_value=0, frequency=200, pin_factory=factory)) for m in MOTORS]
        self.inputs = [(stack.enter_context(DigitalOutputDevice(m.in1, pin_factory=factory)),
                        stack.enter_context(DigitalOutputDevice(m.in2, pin_factory=factory)))
                       for m in MOTORS]
        stack.callback(self.stop)

    def stop(self):
        for en in self.enables:
            en.off()
        for first, second in self.inputs:
            first.off()
            second.off()

    def start(self, key, duty):
        for (first, second), motor, sign in zip(self.inputs, MOTORS, MOVES[key]):
            positive = (sign == 1) != motor.reverse
            first.value, second.value = positive, not positive
        for en, percent in zip(self.enables, wheel_duties(MOVES[key], duty * 100)):
            en.value = percent / 100


def keyboard(screen, wheels, lift):
    screen.keypad(True)
    screen.timeout(30)
    curses.set_escdelay(40)
    screen.addstr("Arrows/WASD: wheels  I/K: lift  +/-: wheels  ]/[: lift  SPACE: stop  Q: quit")
    wheel_duty = lift_duty = 0.5
    active = None
    first_press = last_press = None
    last_stop = float("-inf")
    while True:
        code = screen.getch()
        key = ARROWS.get(code, chr(code).lower() if 0 <= code < 128 else "")
        now = monotonic()
        if key == "q":
            return
        if last_press is not None and now - last_press >= 0.6:
            first_press = None
        motion = key in MOVES or key in ("i", "k")
        if motion:
            last_press = now
            if first_press is None:
                first_press = now
        expired = last_press is None or now - last_press >= 0.3
        capped = first_press is not None and now - first_press >= 2.0
        if active and (expired or capped or (code != -1 and key != active)):
            wheels.stop()
            lift.stop()
            active, last_stop = None, now
        if key in ("+", "=", "-", "]", "["):
            if key in ("[", "]"):
                lift_duty = max(.1, min(1., lift_duty + (.1 if key == "]" else -.1)))
            else:
                wheel_duty = max(.1, min(1., wheel_duty + (-.1 if key == "-" else .1)))
        if motion and not capped and now - last_stop >= .25:
            if key in MOVES and active != key:
                wheels.start(key, wheel_duty)
            elif key in ("i", "k"):
                lift.command(1 if key == "i" else -1, lift_duty)
            active = key
        screen.addstr(1, 0, f"Straight {wheel_duty:.0%}  Turn Fwd 100% Rev 50%  Lift {lift_duty:.0%}   {active or 'STOP'}   ")
        screen.refresh()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--simulate", action="store_true")
    args = parser.parse_args()
    if not sys.stdin.isatty():
        parser.error("키 입력이 가능한 터미널에서 실행하세요.")
    def interrupt(*_):
        raise KeyboardInterrupt
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, interrupt)
    with ExitStack() as stack:
        if args.simulate:
            from gpiozero.pins.mock import MockFactory, MockPWMPin
            factory = MockFactory(pin_class=MockPWMPin)
        else:
            factory = LGPIOFactory()
        stack.callback(factory.close)
        wheels = Wheels(stack, factory)
        lift = Actuator(stack, factory)
        try:
            input("출력 정지 상태. 모터 전원을 켠 뒤 Enter: ")
            curses.wrapper(keyboard, wheels, lift)
        finally:
            wheels.stop()
            lift.stop()
            input("정지. 모터 전원을 끈 뒤 Enter: ")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        pass
