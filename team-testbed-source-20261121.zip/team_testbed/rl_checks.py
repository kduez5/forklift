"""Predeclared three-training-seed study of the frozen simulation candidate.

No hardware APIs. The 80 evaluation environments are shared by all policies;
240 learned-policy evaluations are not 240 independent environments.
"""
from __future__ import annotations

from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import platform
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
TRAIN_SEEDS = (20261121, 20261122, 20261123)
EVAL_SEEDS = tuple(range(5000000, 5000080))
EPISODES = 2500
POLICIES = ('learned', 'untrained', 'phase_rule', 'baseline')
FROZEN_SOURCE_SHA256 = {
    'candidate.py': '2ede3ed9bd3422065a33247bc87d7fb0d363d43706f3f56a73b98f60c0be99ea',
    'environment.py': 'df84c9a6f0ff87fcc25b72e3230d5813089c00504fd0e05d9c4c569d3f1963ac',
    'learning.py': '34bc03bbe213775b7ce8d3bce6a167845d35ce5369a2c263563b659e8da6dcb4',
}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _write(path, payload):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    temporary.replace(path)


def validate_split(train_episode_seeds, evaluation_seeds):
    if not evaluation_seeds or len(set(evaluation_seeds)) != len(evaluation_seeds):
        raise ValueError('Evaluation seeds must be nonempty and unique')
    if any(type(s) is not int or not 0 <= s < 1000000 for s in train_episode_seeds):
        raise ValueError('Training environment seeds must be within 0..999999')
    if any(type(s) is not int or s < 1000000 for s in evaluation_seeds):
        raise ValueError('Evaluation must be outside the training environment range')
    if set(train_episode_seeds) & set(evaluation_seeds):
        raise ValueError('Training/evaluation overlap')
    return True


def wilson95(successes, count):
    if count <= 0 or not 0 <= successes <= count:
        raise ValueError('Invalid binomial counts')
    z = 1.959963984540054
    p = successes / count
    denominator = 1 + z*z/count
    center = (p + z*z/(2*count))/denominator
    half = z*math.sqrt(p*(1-p)/count + z*z/(4*count*count))/denominator
    return [max(0., center-half), min(1., center+half)]


def paired_comparison(learned, comparator):
    a = {r['seed']: r for r in learned['episodes_detail']}
    b = {r['seed']: r for r in comparator['episodes_detail']}
    if len(a) != len(learned['episodes_detail']) or len(b) != len(comparator['episodes_detail']) or a.keys() != b.keys():
        raise ValueError('Paired comparison requires identical unique environments')
    diffs = [a[s]['steps']-b[s]['steps'] for s in sorted(a)]
    return {
        'learned_fails_comparator_succeeds': [s for s in sorted(a) if not a[s]['success'] and b[s]['success']],
        'learned_succeeds_comparator_fails': [s for s in sorted(a) if a[s]['success'] and not b[s]['success']],
        'both_fail': [s for s in sorted(a) if not a[s]['success'] and not b[s]['success']],
        'mean_step_difference_learned_minus_comparator': statistics.mean(diffs),
        'learned_slower_seeds': [s for s in sorted(a) if a[s]['steps'] > b[s]['steps']],
        'learned_faster_seeds': [s for s in sorted(a) if a[s]['steps'] < b[s]['steps']],
        'episodes': len(a),
    }


def nondegradation(learned, baseline, distance_tolerance=.09, heading_tolerance=.25):
    paired = paired_comparison(learned, baseline)
    rows = learned['episodes_detail']
    checks = {
        'preserves_each_baseline_success': not paired['learned_fails_comparator_succeeds'],
        'no_more_physical_collisions': learned['physical_collisions'] <= baseline['physical_collisions'],
        'no_more_blocked_requests': learned['mean_blocked'] <= baseline['mean_blocked'],
        'successful_episodes_meet_frozen_precision': all(
            r['distance_error_m'] <= distance_tolerance and abs(r['heading_error_rad']) <= heading_tolerance
            for r in rows if r['success']),
    }
    return {'passed': all(checks.values()), 'checks': checks,
            'scope': 'Empirical gate on sampled episodes; not statistical equivalence/noninferiority or hardware safety proof'}


def summarize_trials(trials):
    if len(trials) != 3:
        raise ValueError('This preregistered study requires exactly three training seeds')
    common = trials[0]['evaluation_seeds']
    if len(common) != 80 or len(set(common)) != 80:
        raise ValueError('This study requires 80 unique evaluation environments')
    if len({t['settings']['seed'] for t in trials}) != 3:
        raise ValueError('Training RNG seeds must be distinct')
    summaries=[]
    for trial in trials:
        if trial['evaluation_seeds'] != common:
            raise ValueError('All policies/training seeds must use the same evaluation environments')
        policies={}
        for name in POLICIES:
            result=trial[name]
            if [r['seed'] for r in result['episodes_detail']] != common:
                raise ValueError('Policy evaluation environments/order differ')
            if result['q_sha256_before'] != result['q_sha256_after'] or result['evaluation_learning_disabled'] is not True:
                raise ValueError('Evaluation Q immutability evidence failed')
            successes=sum(bool(r['success']) for r in result['episodes_detail'])
            if successes != result['successes'] or result['episodes'] != len(common):
                raise ValueError('Evaluation aggregate does not match episodes')
            policies[name]={k:result[k] for k in ('successes','episodes','success_rate','mean_steps','mean_return','mean_blocked','physical_collisions')}
            policies[name]['success_rate_wilson95']=wilson95(successes,len(common))
        summaries.append({'training_rng_seed':trial['settings']['seed'], 'policies':policies,
                          'paired':{name:paired_comparison(trial['learned'],trial[name]) for name in ('untrained','phase_rule','baseline')},
                          'sampled_nondegradation':nondegradation(trial['learned'],trial['baseline'])})
    aggregate={}
    for name in POLICIES:
        entry={}
        for metric in ('success_rate','mean_steps','mean_return'):
            values=[s['policies'][name][metric] for s in summaries]
            mean=statistics.mean(values)
            half=4.302652729911275*statistics.stdev(values)/math.sqrt(3)
            ci=[mean-half,mean+half]
            if metric=='success_rate': ci=[max(0.,ci[0]),min(1.,ci[1])]
            entry[metric]={'mean_over_training_seeds':mean,'seed_values':values,
                           'approximate_t95_over_training_seeds':ci}
        aggregate[name]=entry
    gate=all(s['sampled_nondegradation']['passed'] for s in summaries)
    efficiency=all(t['learned']['mean_steps'] < t['baseline']['mean_steps'] for t in trials)
    return {'unique_evaluation_environments':80,'learned_policy_evaluation_episodes':240,
            'policy_episode_evaluations_including_three_repeated_controls':960,
            'training_seed_count':3,'trial_summaries':summaries,'aggregate':aggregate,
            'all_sampled_nondegradation_gates_passed':gate,
            'all_training_seeds_strictly_faster_than_baseline':efficiency,
            'candidate_adoption_gate_passed':gate and efficiency,
            'statistics_limits':[
                'Per-policy Wilson intervals are conditional on one frozen policy and assume evaluation environment seeds sample the assumed simulator distribution independently.',
                'The same 80 environments are reused across policies and three training seeds. Do not pool this as 240 independent environments.',
                't95 intervals summarize only three training-seed means, conditional on this common evaluation set; n=3 is exploratory and normality is unverified.',
                'Zero between-seed control variance or a degenerate interval is not certainty about other environments or hardware.',
                'No multiplicity-adjusted significance or isolated RL superiority claim is made; candidate contains phase rules, memory, STOP settling and action masks.',
            ]}


def _case(identifier,title,status,evidence,requirements):
    return {'id':identifier,'title':title,'status':status,'passed':status=='PASS',
            'evidence':evidence,'requirement_ids':requirements,'source_ids':['iteration'],
            'coverage_level':'reproducible_synthetic_rl_study','hardware_accessed':False,'hardware_verified':False}


def run_rl_checks(output: Path) -> list[dict]:
    output=Path(output)
    output.mkdir(parents=True,exist_ok=True)
    try:
        import numpy as np
    except ImportError as exc:
        return [_case('RL01','세 학습 seed 오프라인 연구','NOT_EVALUATED',{'reason':str(exc),'dependency':'numpy'},['A05','T05','G7'])]
    actual={name:_sha(ROOT/'autonomy_lab'/name) for name in FROZEN_SOURCE_SHA256}
    if actual != FROZEN_SOURCE_SHA256:
        raise ValueError('Frozen RL source hash differs; use a separately reviewed study')
    from autonomy_lab.candidate import run_candidate_experiment, EnvironmentConfig, PhaseConfig
    config,phase=EnvironmentConfig(),PhaseConfig()
    validate_split([],EVAL_SEEDS)
    manifest={'schema_version':1,'mode':'simulation_only','training_rng_seeds':list(TRAIN_SEEDS),
              'episodes_per_training_seed':EPISODES,'training_environment_seed_range':[0,999999],
              'evaluation_seeds':list(EVAL_SEEDS),'evaluation_environment_count':80,
              'known_previously_used_evaluation_ranges':[[2000000,2000039],[3000000,3000079],[4000000,4000079]],
              'freshness_scope':'5000000..5000079 were not used in this session before this predeclared study; global historical usage is not independently established.',
              'environment':asdict(config),'phase_config':asdict(phase),
              'learning':{'alpha':.16,'gamma':config.gamma,'epsilon_start':.90,'epsilon_end':.05,'epsilon_decay_episodes':3500},
              'frozen_source_sha256':actual,'study_source_sha256':_sha(__file__),
              'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),
              'predeclared_adoption_gate':{'sampled_nondegradation':'Every baseline success preserved; no more blocks/collisions; successful terminal errors inside frozen tolerances.',
                'efficiency':'Mean steps strictly less than baseline in every one of the three training seeds.',
                'statistical_scope':'Descriptive finite-set gate, not a statistical superiority test or physical acceptance.'},
              'hardware_accessed':False,'actual_motion_permission':False}
    # JSON normalizes tuple-valued configuration (notably obstacles) to lists.
    manifest=json.loads(json.dumps(manifest,allow_nan=False))
    manifest_path=output/'study_manifest.json'
    if manifest_path.exists():
        if json.loads(manifest_path.read_text(encoding='utf-8')) != manifest:
            raise ValueError('Existing study manifest differs; preserve it and choose a fresh directory')
    else:
        if any(output.iterdir()):
            raise ValueError('New study output must be empty')
        _write(manifest_path,manifest)
    if (output/'study_result.json').exists():
        saved=json.loads((output/'study_result.json').read_text(encoding='utf-8'))
        for filename,expected in saved['artifact_sha256'].items():
            artifact=(output/filename).resolve()
            artifact.relative_to(output.resolve())
            if _sha(artifact) != expected:
                raise ValueError('Saved study artifact changed: '+filename)
        print('RL study: verified existing completed artifacts; no retraining',flush=True)
        return saved['cases']
    trials=[]; audits=[]
    for index,seed in enumerate(TRAIN_SEEDS,1):
        print(f'RL study {index}/3: training seed {seed}, {EPISODES} episodes; synthetic only',flush=True)
        folder=output/f'train_{seed}'
        result=run_candidate_experiment(folder,episodes=EPISODES,seed=seed,eval_episodes=len(EVAL_SEEDS),
                    eval_seed_start=EVAL_SEEDS[0],evaluation_label='final_holdout',config=config,phase_config=phase)
        checkpoint=json.loads((folder/'checkpoint.json').read_text(encoding='utf-8'))
        log=[json.loads(line) for line in (folder/'training.jsonl').read_text(encoding='utf-8').splitlines()]
        validate_split([row['seed'] for row in log],result['evaluation_seeds'])
        if len(log)!=EPISODES or result['completed_episodes']!=EPISODES or [r['episode'] for r in log]!=list(range(1,EPISODES+1)):
            raise ValueError('Training episode evidence incomplete')
        if result['q_updates']!=sum(r['steps'] for r in log) or not result['q_nonzero_entries'] or not sum(r['absolute_td_update'] for r in log)>0:
            raise ValueError('Learning TD-update evidence missing')
        qpath=folder/checkpoint['q_file']
        if _sha(qpath)!=checkpoint['q_file_sha256']:
            raise ValueError('Saved policy checksum differs')
        with np.load(qpath,allow_pickle=False) as archive:
            qhash=hashlib.sha256(archive['q'].tobytes()).hexdigest()
        if qhash!=result['learned']['q_sha256_before'] or qhash!=result['learned']['q_sha256_after']:
            raise ValueError('Evaluated Q differs from the saved trained Q')
        audits.append({'training_rng_seed':seed,'episodes':len(log),'q_updates':result['q_updates'],
                       'q_nonzero_entries':result['q_nonzero_entries'],'policy_array_sha256':qhash,
                       'policy_file':str(qpath.relative_to(output)),'policy_file_sha256':_sha(qpath),
                       'evaluation_q_hashes':{name:[result[name]['q_sha256_before'],result[name]['q_sha256_after']] for name in POLICIES},
                       'training_evaluation_disjoint':True})
        trials.append(result)
        print(f"RL study {index}/3 complete: learned {result['learned']['successes']}/80; baseline {result['baseline']['successes']}/80",flush=True)
    summary=summarize_trials(trials)
    if any(trials[0][name]['episodes_detail'] != trial[name]['episodes_detail'] for trial in trials[1:] for name in ('untrained','phase_rule','baseline')):
        raise ValueError('Repeated deterministic control conditions changed')
    if {name:_sha(ROOT/'autonomy_lab'/name) for name in FROZEN_SOURCE_SHA256} != actual:
        raise ValueError('Frozen source changed during the study')
    cases=[
        _case('RL01','동결 소스·사전 분할·3개 학습 seed의 실제 TD 갱신','PASS',{'manifest':'study_manifest.json','training_audits':audits},['A05','A09','T05','T09','G7']),
        _case('RL02','동일 80환경 비교·평가 Q 불변·공통 기준기 재현','PASS',{'unique_environments':80,'learned_policy_episodes':240,'all_policy_episode_evaluations':960,'controls_identical_across_training_runs':True},['A05','T05','G7']),
        _case('RL03','기준기 대비 표본별 성공·제약·정밀도 비열화','PASS' if summary['all_sampled_nondegradation_gates_passed'] else 'CONTRACT_CONFLICT',{'per_seed':[s['sampled_nondegradation'] for s in summary['trial_summaries']],'paired_failures':[s['paired']['baseline'] for s in summary['trial_summaries']]},['A05','A09','T05','G7']),
        _case('RL04','사전 효율 목표와 채택 조건','PASS' if summary['candidate_adoption_gate_passed'] else 'CONTRACT_CONFLICT',{'gate':manifest['predeclared_adoption_gate'],'all_seeds_strictly_faster':summary['all_training_seeds_strictly_faster_than_baseline'],'aggregate':summary['aggregate'],'decision':'Offline gate only; no hardware deployment or isolated RL superiority conclusion.'},['A05','A09','T05','G7']),
        _case('RL05','센서 융합·리프트·실물 강화학습','NOT_EVALUATED',{'reason':'This frozen model supplies synthetic goal-relative pose, uses ideal STOP and no lift/load/contact/electrical dynamics; no hardware accessed.'},['A01','A03','A04','A07','A08','S01','S02','S03','S04','S05','S10'])]
    _write(output/'study_summary.json',summary)
    artifacts={str(p.relative_to(output)):_sha(p) for p in sorted(output.rglob('*')) if p.is_file() and p.name!='study_result.json'}
    payload={'schema_version':1,'manifest':'study_manifest.json','summary':'study_summary.json',
             'cases':cases,'artifact_sha256':artifacts,'hardware_accessed':False,'actual_motion_permission':False}
    _write(output/'study_result.json',payload)
    return cases
