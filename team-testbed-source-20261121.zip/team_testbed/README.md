# 팀 코드·계약·강화학습 통합 시험

PC에서 기존 팀 코드의 선택 로직, 새 통합 계약, 합성 접근·정렬 RL을 검사한다. 실행해도 실제 로봇은 움직이지 않는다. **실물 제어기나 자율운반 완성본이 아니다.**

## 실행

Python 3.11 이상과 RL용 NumPy가 필요하다. 이 작업에서 검증한 환경은 Python 3.11.2 / NumPy 2.3.1이다. 패키지 설치는 별도 가상환경에서 한다.

```powershell
python -m pip install numpy==2.3.1
python -m team_testbed --suite all
python -m unittest discover -s team_testbed/tests
```

먼저 짧게 확인하려면 `--suite contracts` 또는 `--suite team`, 학습만 하려면 `--suite rl`을 쓴다. `all`은 3개 학습 seed × 2,500 episode를 포함한다. 출력 폴더를 지정하지 않으면 실행마다 새 `outputs/team_testbed_<시각>`에 저장한다. 같은 report 폴더는 덮어쓰지 않는다.

Notion 원문은 공개 저장소에 포함하지 않는다. 공유 Notion 페이지의 **source_pack.json**을 다운로드한 팀원은 다음처럼 두 개의 검토된 원문을 함께 검사한다.

```powershell
python -m team_testbed --suite all --notion-pack "C:\Downloads\source_pack.json"
```

원문이 없거나 해시가 바뀌면 해당 원문 검사는 `NOT_EVALUATED`다. 여기 있는 hash/import 검사는 검토한 소스를 고정하는 장치이며 임의 코드를 안전하게 실행하는 sandbox가 아니다. pack의 텍스트를 편집하거나 화이트리스트를 우회하지 않는다.

**종료코드:** 0=선택한 검사 통과, 1=검사/실행 실패, 2=실행 완료 및 계약 충돌·미평가 있음. 현재 알려진 원문 충돌 때문에 2가 예상된다. `REPORT.md`와 `report.json`을 함께 본다. 새 출력 디렉터리에서 다시 실행하면 새 기록이 생성된다.

## 무엇을 실제로 시험하는가

| 구성 | 실행 내용 | 해석 한계 |
|---|---|---|
| team_adapters.py | GitHub ZIP의 선택된 바퀴·리프트·초음파·키보드 함수/클래스 + fake I/O/clock | 모터·센서를 열지 않음. main/설치 스크립트 실행 없음 |
| notion_adapters.py | 고정 원문 ObstacleGuard·LoadingMachine + 메모리 drive | Notion 전체 코드 실행이나 최신 HAL 통합 아님 |
| domain_checks.py | 평면 좌표/외곽/정지 식/리프트 기준/증거 임무 FSM/SQLite/보상/진단/permit 기준 모델 | 새 검증 oracle이며 운영 제어기 아님. 값은 합성 가정 |
| integration_contracts | 타임스탬프·source·세대·순번·유효성·거리 상충 등의 15 fixture | 카메라 이미지 인식·실제 LiDAR scan 취득/학습 아님 |
| rl_checks.py | 동결된 단계 규칙+Q-learning 후보의 3seed 비교 | 합성 2D 접근·정렬만. 리프트/적재/실제 센서 학습 없음 |
| 기존 회귀 검사 | manual_station/autonomy_lab/integration_contracts의 unittest | POSIX 전용 skip과 누락 패키지를 명시 |

Notion·Git 조사에서 찾은 작업지시서/코드의 요구는 `data/notion_requirements.json`, `git_requirements.json`에 반영했다. 구현을 읽거나 등록한 것과 실제 실행한 것을 구분한다. vision/LiDAR/경로/작업 큐/실제 DB/lease/PID/QR/ArUco/NFC 등 미연결 부분도 보고서에 남긴다.

## 원문과 충돌

Git 기준은 main `8b41ff293dc399a42b37a2f54f71c71ada61b32f`의 두 ZIP이다. 수동 패키지 PR1과 자율 패키지 PR2는 검토 시점에 미병합이다. `data/git_source_manifest.json`은 exact-byte SHA256을 기록한다. 공개 Git 원문은 `vendor/*.txt`로 보관하며 변조된 소스는 실행하지 않는다.

발견한 충돌은 별도 `CONTRACT_CONFLICT` 결과다. 회전 시 50/100% 출력, 리프트 기준점/상하한 인터페이스 부재, 초음파 큐 비우기의 총 시간 경계 부재, 장애물 clear 후 자동 재개, 급접근 없이 근거리로 들어갈 때 절대거리 차단 부재를 숨기지 않는다. 팀 원문 동작 자체가 재현되어 PASS여도 현재 통합 요구에 적합하다는 의미는 아니다.

## 요구사항·개선 작업

`data/requirements.json`에 기존 작업지시서 3개의 **공유본 전체 본문**과 A/F/G/S/T 및 MANUAL ID를 보존했다. 수동 지시서는 개인 장치 주소·로그인을 제외한 기존 PR1 공개본을 사용하며 기술 요구는 유지한다. 별도 팀 요구 registry를 합쳐 모든 ID를 보고서에 출력한다. 한 fixture가 PASS여도 `full_acceptance_verified=false`, 현물은 `NOT_EVALUATED`다. 아무 사례가 없는 요구도 누락하지 않는다.

[새 통합 작업지시서](../docs/team_integration_test_work_order_20261121.md), [복사할 /goal 프롬프트](GOAL_PROMPT.md)를 사용한다. 실제 동작 시작은 후속 사용자 지시·현장 확인·별도 검증이 필요한 단계다. 실물 체크항목을 이 프로그램에서 자동 승인하지 않는다.

[실제 검증 결과](VERIFICATION.md): 신규76시험 통과, 통합87사례 중74통과·7계약충돌·6미평가. 3seed RL 성공80/80·68/80·16/80으로 현재 후보는 채택 조건을 충족하지 못했다.

공유 ZIP은 `team_testbed`, 이미 공유된 의존 패키지, 지시서와 실행 안내를 포함한다. 새 폴더에 풀고 그 폴더에서 위 명령을 실행한다. 기존 팀 폴더에 덮어 풀지 않는다. 비공개 Notion 원문 pack은 같은 팀 Notion 페이지에서 별도로 받는다.
