"""Offline checks of selected, hash-pinned original team source definitions.

Original imports/main functions are never executed. All selected control I/O,
clock, keyboard and echo queues are bounded local fixtures, never devices.
"""
from __future__ import annotations

import ast
from contextlib import ExitStack
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace


BASE = Path(__file__).resolve().parent
EXPECTED_HASHES = {
    'GH-SR04': 'aaa383c74e21125af7c747b2591f58fa61cde82b5d531ba2f5cc46f71e50855f',
    'GH-WHEELS': '2d64d743d72a045c9c9660a62108cbd708a682925033a6424c24cf19911d2a25',
    'GH-MANUAL': '7f59120df7fea36a64593e4a105304a15ae8a73c9b3a61835f865624d370cbc6',
    'GH-LINEAR': 'f76ec61c57254e89132d89ad01da69f7ccfb6c1abaaafd24ffa53a0949add6ab',
    'GH-PR1-CONTROLLER': '09ae2c59a663f951f7c1bb3b1001d7f896eba1b8df7fb4d6d0503c1ab21355c6',
    'GH-PR1-CONFIG': '9e2f92ddff12287cef0e30b49077045ebcc1dff9e82378ff4099c10e06f2e23e',
}
REVIEWED_NODES = {
    'GH-SR04': frozenset(('measure_cm',)),
    'GH-WHEELS': frozenset(('Motor','MOTORS','PWM_HZ','wheel_duties','WheelDrive','run_sequence')),
    'GH-MANUAL': frozenset(('MOVES','ARROWS','keyboard')),
    'GH-LINEAR': frozenset(('Actuator',)),
    'GH-PR1-CONTROLLER': frozenset(),
    'GH-PR1-CONFIG': frozenset(),
}


def source_manifest():
    return json.loads((BASE/'data/git_source_manifest.json').read_text(encoding='utf-8'))


def _source(source_id):
    entry = next(s for s in source_manifest()['sources'] if s['id'] == source_id)
    path = (BASE/entry['vendor_file']).resolve()
    path.relative_to(BASE/'vendor')
    data = path.read_bytes()
    expected = EXPECTED_HASHES[source_id]
    if entry['entry_sha256'] != expected or hashlib.sha256(data).hexdigest() != expected:
        raise ValueError('Original source hash differs from reviewed snapshot: '+source_id)
    return data.decode('utf-8-sig'), entry


def _node_name(node):
    if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
        return node.name
    if isinstance(node, ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0], ast.Name):
        return node.targets[0].id
    return None


def _load(source_id, selected, injected=None):
    """Select known reviewed source definitions, not a general Python sandbox."""
    if not set(selected) <= REVIEWED_NODES[source_id]:
        raise ValueError('Requested definition is outside the reviewed selection')
    text, entry = _source(source_id)
    original = ast.parse(text)
    chosen = [n for n in original.body if _node_name(n) in selected]
    if {_node_name(n) for n in chosen} != set(selected):
        raise ValueError('Missing reviewed original AST definition')
    if any(isinstance(n,(ast.Import,ast.ImportFrom)) for top in chosen for n in ast.walk(top)):
        raise ValueError('Imports are not allowed inside selected original definitions')
    builtins = {'__build_class__':__build_class__, 'object':object, 'str':str, 'int':int,
                'float':float, 'bool':bool, 'tuple':tuple, 'list':list, 'set':set,
                'len':len, 'range':range, 'zip':zip, 'enumerate':enumerate, 'round':round,
                'min':min, 'max':max, 'any':any, 'all':all, 'reversed':reversed,
                'chr':chr, 'ord':ord, 'Exception':Exception, 'BaseException':BaseException,
                'RuntimeError':RuntimeError, 'ValueError':ValueError, 'TypeError':TypeError}
    namespace = {'__name__':'offline_reviewed_'+source_id.replace('-','_'),
                 '__builtins__':builtins, 'dataclass':dataclass, 'print':lambda *a,**kw:None}
    namespace.update(injected or {})
    code = compile(ast.Module(body=chosen,type_ignores=[]), entry['vendor_file'], 'exec', dont_inherit=True)
    exec(code, namespace)
    return namespace


class FixtureBudgetExceeded(RuntimeError):
    pass


class FakeClock:
    def __init__(self, now=10.0):
        self.now=now
        self.sleeps=[]
        self.monotonic_calls=0

    def monotonic(self):
        self.monotonic_calls+=1
        return self.now

    def sleep(self, duration):
        if not 0 <= duration <= 3:
            raise FixtureBudgetExceeded('Unexpected fake sleep')
        self.sleeps.append(duration)
        self.now+=duration


class FakeLock:
    def __enter__(self):
        return self

    def __exit__(self,*args):
        return False


class FakeDevice:
    def __init__(self,pin,events,initial_value=0,**kwargs):
        self.pin,self.events,self.closed,self._value=pin,events,False,initial_value
        events.append(('create',pin,initial_value))

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self,value):
        self._value=value
        self.events.append(('value',self.pin,value))

    def off(self):
        self.value=0

    def close(self):
        self.off()
        self.closed=True

    def __enter__(self):
        return self

    def __exit__(self,*args):
        self.close()


class FakeGPIO:
    def __init__(self,fail_claim=None,fail_pwm=None):
        self.events=[]
        self.fail_claim,self.fail_pwm=fail_claim,fail_pwm

    def gpio_claim_output(self,handle,pin,level):
        if pin==self.fail_claim:
            raise RuntimeError('synthetic claim failure')
        self.events.append(('claim',pin,level))

    def gpio_write(self,handle,pin,level):
        self.events.append(('write',pin,level))

    def tx_pwm(self,handle,pin,hz,duty,**kwargs):
        self.events.append(('pwm',pin,hz,duty,kwargs))
        if hz and pin==self.fail_pwm:
            raise RuntimeError('synthetic PWM failure')
        return 0

    def gpio_free(self,handle,pin):
        self.events.append(('free',pin))

    def gpiochip_close(self,handle):
        self.events.append(('close',))


class FakeStop:
    def __init__(self,events=None,cancelled=False,cancel_on=None):
        self.events=events if events is not None else []
        self.cancelled,self.cancel_on=cancelled,cancel_on

    def is_set(self):
        return self.cancelled

    def wait(self,seconds):
        self.events.append(('wait',seconds))
        if seconds==self.cancel_on:
            self.cancelled=True
        return self.cancelled


def _wheels():
    return _load('GH-WHEELS',('Motor','MOTORS','PWM_HZ','wheel_duties','WheelDrive','run_sequence'))


def _actuator(clock,events):
    return _load('GH-LINEAR',('Actuator',),{
        'time':clock,'threading':SimpleNamespace(RLock=FakeLock),
        'PWMOutputDevice':lambda pin,**kw:FakeDevice(pin,events,**kw)})['Actuator']


def check_provenance():
    verified=[]
    for sid in EXPECTED_HASHES:
        text,entry=_source(sid)
        ast.parse(text)
        verified.append({'source_id':sid,'sha256':entry['entry_sha256'],'bytes':len(text.encode('utf-8'))})
    return 'PASS',{'verified_sources':verified,'imports_or_main_executed':False}


def check_wheel_translation():
    ns=_wheels()
    f=ns['wheel_duties']
    outputs={'forward':f((1,1,1,1),20),'reverse':f((-1,-1,-1,-1),20),
             'left':f((-1,-1,1,1),20),'right':f((1,1,-1,-1),20)}
    assert outputs=={'forward':(20,20,20,20),'reverse':(20,20,20,20),
                     'left':(50,50,100,100),'right':(100,100,50,50)}
    return 'PASS',{'requested_straight_percent':20,'observed_pwm_percent':outputs,
                   'physical_motion_verified':False,'scope':'Original wheel_duties output, not an approval of its limits'}


def check_wheel_lifecycle():
    ns=_wheels(); gpio=FakeGPIO(); drive=ns['WheelDrive'](gpio,0)
    drive.claim()
    assert gpio.events[:4]==[('claim',m.enable,0) for m in ns['MOTORS']]
    ns['run_sequence'](drive,FakeStop(gpio.events),duty=20,forward_seconds=.1,
                       turn_seconds=.1,reverse_seconds=.1,spin_seconds=.1)
    enabled=set(); directions=[]; levels={}; starts=[]
    direction_pins={p for m in ns['MOTORS'] for p in (m.in1,m.in2)}
    for event in gpio.events:
        if event[0]=='write':
            if event[1] in direction_pins:
                assert not enabled,'Direction changed with simulated PWM enabled'
            levels[event[1]]=event[2]
        elif event[0]=='pwm':
            if event[2]:
                if event[1]==ns['MOTORS'][0].enable:
                    directions.append([levels[m.in1] for m in ns['MOTORS']])
                enabled.add(event[1]); starts.append(event)
            else:
                enabled.discard(event[1])
        elif event==('wait',.5):
            assert not enabled
    assert directions==[[0,0,0,0],[1,1,0,0],[0,0,1,1],[1,1,1,1],[1,1,0,0]]
    assert len(starts)==20 and all(e[4]['pulse_cycles']==20 for e in starts)
    assert not enabled and drive.close()==[]
    return 'PASS',{'sequence_direction_in1_levels':directions,'pwm_starts':len(starts),
                   'pulse_cycles_per_channel':20,'fake_waits':[e[1] for e in gpio.events if e[0]=='wait'],
                   'all_enable_claims_low_first':True,'hardware_verified':False}


def check_wheel_failures():
    ns=_wheels(); motors=ns['MOTORS']; outcomes={}
    for kind,gpio in [('partial_claim',FakeGPIO(fail_claim=motors[1].enable)),
                      ('pwm_failure',FakeGPIO(fail_pwm=motors[1].enable))]:
        drive=ns['WheelDrive'](gpio,0)
        try:
            drive.claim(); drive.forward(20,.1,FakeStop())
        except RuntimeError:
            pass
        else:
            raise AssertionError('Injected fault did not reach original error path')
        claimed=list(drive.claimed)
        drive.close()
        for motor in motors:
            if motor.enable in claimed:
                assert ('write',motor.enable,0) in gpio.events
        if kind=='partial_claim':
            assert not any(e[0]=='pwm' and e[2] for e in gpio.events)
        outcomes[kind]={'claimed_before_cleanup':claimed,'events':gpio.events}
    gpio=FakeGPIO(); drive=ns['WheelDrive'](gpio,0); drive.claim()
    drive.forward(20,.1,FakeStop(cancelled=True))
    assert not any(e[0]=='pwm' for e in gpio.events)
    drive.close()
    outcomes['pre_cancel']='No PWM request observed'
    return 'PASS',outcomes


def check_keyboard_timeout():
    clock=FakeClock(); calls=[]
    curses=SimpleNamespace(KEY_UP=259,KEY_DOWN=258,KEY_LEFT=260,KEY_RIGHT=261,set_escdelay=lambda n:None)
    ns=_load('GH-MANUAL',('MOVES','ARROWS','keyboard'),{'curses':curses,'monotonic':clock.monotonic})
    class Screen:
        events=iter([(10.0,ord('w')),(10.1,-1),(10.31,-1),(10.4,ord('i')),
                     (10.57,ord('i')),(10.9,-1),(11.0,ord('q'))])
        def keypad(self,value): pass
        def timeout(self,value): pass
        def addstr(self,*args): pass
        def refresh(self): pass
        def getch(self):
            clock.now,key=next(self.events)
            return key
    wheels=SimpleNamespace(start=lambda key,duty:calls.append(('wheels',clock.now,key,duty)),
                           stop=lambda:calls.append(('wheel_stop',clock.now)))
    lift=SimpleNamespace(command=lambda direction,duty:calls.append(('lift',clock.now,direction,duty)),
                         stop=lambda:calls.append(('lift_stop',clock.now)))
    ns['keyboard'](Screen(),wheels,lift)
    assert ('wheels',10.0,'w',.5) in calls
    assert ('wheel_stop',10.31) in calls and ('lift_stop',10.31) in calls
    assert not any(x[0]=='lift' and x[1]==10.4 for x in calls)
    assert ('lift',10.57,1,.5) in calls
    assert ('lift_stop',10.9) in calls
    return 'PASS',{'routing_calls':calls,'timeout_observed_s':.31,'switch_wait_s':.26,
                   'default_duty_percent':50,'scope':'Original keyboard loop with fake getch/clock; main/finally and OS scheduling not executed'}


def check_lift_limits_in_time():
    clock=FakeClock(); events=[]; cls=_actuator(clock,events)
    with ExitStack() as stack:
        motor=cls(stack,None); motor.command(1,.2)
        assert motor.in1.value==.2 and motor.in2.value==0
        clock.now+=.31; motor.tick()
        assert motor.direction==0 and motor.in1.value==motor.in2.value==0
        clock.now=11.0; motor.command(1,.2)
        for i in range(1,10):
            clock.now=11+i*.2; motor.command(1,.2)
        clock.now=13.01; motor.command(1,.2)
        assert motor.latched and motor.direction==0
        clock.now=13.2; motor.command(1,.2)
        assert motor.direction==0
        clock.now=13.81; motor.command(1,.2)
        assert not motor.latched and motor.direction==1
    return 'PASS',{'input_timeout_s':cls.TIMEOUT,'burst_limit_s':cls.MAX_BURST,
                   'release_to_rearm_s':cls.RELEASE,'forced_stop_and_new_input_after_release_observed':True,
                   'tick_calls':'Explicit fake-clock calls; watchdog thread timing not evaluated','events':events}


def check_lift_reverse_pause():
    clock=FakeClock(); events=[]; cls=_actuator(clock,events)
    with ExitStack() as stack:
        motor=cls(stack,None); motor.command(1,.2)
        clock.now+=.1; motor.command(-1,.2)
        assert abs(clock.sleeps[-1]-.25)<1e-9
        assert motor.in1.value==0 and motor.in2.value==.2
        try:
            motor.command(0,.2)
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid direction accepted')
        assert motor.in1.value==motor.in2.value==0
    return 'PASS',{'fake_sleep_durations':clock.sleeps,'invalid_command_stops_outputs':True,'events':events}


class FakeEchoLines:
    def __init__(self,clock,batches=(),already_high=False,continuous_stale=False):
        self.clock,self.batches=clock,list(batches)
        self.already_high,self.continuous_stale=already_high,continuous_stale
        self.writes=[]; self.polls=0

    def wait_edge_events(self,timeout):
        self.polls+=1
        if self.polls>50:
            raise FixtureBudgetExceeded('Stopped after 50 synthetic echo queue polls')
        if timeout==0:
            return self.continuous_stale
        if self.batches:
            return True
        self.clock.sleep(timeout)
        return False

    def read_edge_events(self):
        if self.continuous_stale:
            return [SimpleNamespace(line_offset=12,event_type='rise',timestamp_ns=1)]
        return self.batches.pop(0) if self.batches else []

    def get_value(self,pin):
        return int(self.already_high)

    def set_value(self,pin,value):
        self.writes.append((pin,value))


def _measure(clock):
    return _load('GH-SR04',('measure_cm',),{'time':clock,'Value':SimpleNamespace(ACTIVE=1,INACTIVE=0),
                 'gpiod':SimpleNamespace(EdgeEvent=SimpleNamespace(Type=SimpleNamespace(RISING_EDGE='rise')))})['measure_cm']


def check_echo_measurement():
    clock=FakeClock(); measure=_measure(clock)
    event=lambda pin,kind,ns:SimpleNamespace(line_offset=pin,event_type=kind,timestamp_ns=ns)
    lines=FakeEchoLines(clock,[[event(99,'rise',1),event(12,'rise',1000000),event(12,'fall',2000000)]])
    distance=measure(lines,16,12)
    assert abs(distance-17.15)<1e-12 and lines.writes==[(16,1),(16,0)]
    high=FakeEchoLines(clock,already_high=True)
    assert measure(high,16,12) is None and high.writes==[]
    missing=FakeEchoLines(clock,[[event(12,'fall',2000000)]])
    assert measure(missing,16,12) is None
    timeout=FakeEchoLines(clock)
    assert measure(timeout,16,12) is None and timeout.writes[-1]==(16,0)
    return 'PASS',{'fake_pulse_ns':1000000,'returned_distance_cm':distance,
                   'echo_high_without_trigger':None,'missing_rise':None,'timeout':None,
                   'unrelated_line_ignored':True,'trigger_off_after_pulse':True,
                   'scope':'Original conversion/control flow, no real ultrasonic acquisition or accuracy verification'}


def _literal_assignment(source_id,name):
    text,_=_source(source_id)
    node=next(n for n in ast.parse(text).body if _node_name(n)==name)
    return ast.literal_eval(node.value)


def check_pin_map():
    motors=_wheels()['MOTORS']
    sensors=_literal_assignment('GH-SR04','SENSORS')
    switch=_literal_assignment('GH-SR04','SWITCH')
    linear,_=_source('GH-LINEAR')
    nodes=ast.parse(linear)
    pin_loop=next(n for n in ast.walk(nodes) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='pin')
    lift=ast.literal_eval(pin_loop.iter)
    groups={'wheels':[p for m in motors for p in (m.in1,m.in2,m.enable)],
            'ultrasonic':[p for _,trig,echo in sensors for p in (trig,echo)],'switch':[switch],'lift':list(lift)}
    pins=[p for values in groups.values() for p in values]
    assert len(pins)==len(set(pins))
    return 'PASS',{'declared_bcm_pins':groups,'conflicts_within_these_archives':[],
                   'actual_wiring_verified':False,'other_team_peripherals_pin_ownership':'NOT_EVALUATED'}


def check_turn_ceiling_conflict():
    ns=_wheels(); duties=ns['wheel_duties']((-1,-1,1,1),20)
    ceiling=_literal_assignment('GH-PR1-CONFIG','MAX_DUTY')
    text,_=_source('GH-PR1-CONTROLLER')
    defaults=[n.args[1].value for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Call)
              and isinstance(n.func,ast.Attribute) and n.func.attr=='get' and len(n.args)>=2
              and isinstance(n.args[0],ast.Constant) and n.args[0].value=='duty' and isinstance(n.args[1],ast.Constant)]
    assert defaults==[20] and ceiling==40.0 and max(duties)==100
    return 'CONTRACT_CONFLICT',{'main_archive_requested_percent':20,'main_archive_turn_outputs_percent':duties,
      'manual_station_pr1_default_percent':defaults[0],'manual_station_pr1_absolute_ceiling_percent':ceiling,
      'conflict':'The original turn mixer emits 50/100% despite a 20% request; it is incompatible with the current <=40% station contract.',
      'required_resolution':'Owner-reviewed integration must define one bounded duty contract; original source is preserved unchanged.'}


def check_lift_feedback_contract():
    clock=FakeClock(); events=[]; cls=_actuator(clock,events)
    with ExitStack() as stack:
        motor=cls(stack,None); motor.command(1,.2)
        observed=motor.in1.value
    assert observed==.2
    return 'CONTRACT_CONFLICT',{'original_command_accepted_without_position_reference_or_limit_input':True,
      'fake_pwm_value':observed,'current_requirement':'A08/F27/F28 require UNKNOWN initial height and verified reference/limit contracts before autonomous lift control.',
      'scope':'This raw class is documented as a manual test with no position/current feedback; the result is an integration capability gap, not a physical test.',
      'required_resolution':'Keep lift automation disabled until independent reference/limit/current evidence and a guarded adapter are provided.'}


def check_echo_drain_bound():
    clock=FakeClock(); lines=FakeEchoLines(clock,continuous_stale=True)
    try:
        _measure(clock)(lines,16,12)
    except FixtureBudgetExceeded:
        pass
    else:
        raise AssertionError('Expected synthetic continuously nonempty queue to reach fixture budget')
    assert clock.monotonic_calls==0 and lines.writes==[]
    return 'CONTRACT_CONFLICT',{'nonempty_stale_queue_polls_before_fixture_stopped':50,
      'source_deadline_checks_reached':clock.monotonic_calls,'trigger_started':False,
      'conflict':'The 40ms deadline is established only after the initial queue-drain loop. Under a continuously nonempty synthetic queue that loop has no source-level deadline.',
      'required_resolution':'A future owner-reviewed sensor adapter needs a bounded drain/total acquisition budget; no original code was altered.',
      'scope':'Fault injection of original loop, not measured kernel queue behavior or sensor latency.'}


def run_team_checks():
    if not __debug__:
        raise RuntimeError('Run these assertion-based checks without Python -O')
    definitions=[
      ('TEAM01','Git 원문 해시와 AST 출처',check_provenance,['TEAM-SOURCE-PROVENANCE','A10'],list(EXPECTED_HASHES),'static_source_contract'),
      ('TEAM02','원본 휠 방향·PWM 혼합',check_wheel_translation,['TEAM-WHEEL-IO','A02','A06','F03','F04','F05'],['GH-WHEELS'],'original_logic_stubbed_io'),
      ('TEAM03','원본 휠 EN·방향·PWM 해제 순서',check_wheel_lifecycle,['TEAM-WHEEL-IO','A02','F01','F02'],['GH-WHEELS'],'original_logic_stubbed_io'),
      ('TEAM04','원본 부분 claim/PWM 실패·취소 정리',check_wheel_failures,['TEAM-WHEEL-IO','A09','F01','F36'],['GH-WHEELS'],'original_logic_stubbed_io'),
      ('TEAM05','원본 키 입력 만료·주행/리프트 라우팅',check_keyboard_timeout,['TEAM-MANUAL-LEASE','A02','F02','F29'],['GH-MANUAL'],'original_logic_stubbed_io'),
      ('TEAM06','원본 리프트 시간 제한·재입력',check_lift_limits_in_time,['TEAM-LIFT-WATCHDOG','A08','F02','F22'],['GH-LINEAR'],'original_logic_stubbed_io'),
      ('TEAM07','원본 리프트 역전 대기·잘못된 명령 정지',check_lift_reverse_pause,['TEAM-LIFT-WATCHDOG','A08','F05','F22'],['GH-LINEAR'],'original_logic_stubbed_io'),
      ('TEAM08','원본 초음파 edge 변환·무응답',check_echo_measurement,['TEAM-SR04-EDGE','A01','A04','F10','F11'],['GH-SR04'],'original_logic_stubbed_io'),
      ('TEAM09','두 ZIP에 선언된 BCM 핀 중복 검사',check_pin_map,['TEAM-PIN-CONFLICT','A06','A10','F01','F31'],['GH-WHEELS','GH-LINEAR','GH-SR04'],'static_source_contract'),
      ('TEAM10','팀 회전 50/100%와 현행 20/40% 계약 차이',check_turn_ceiling_conflict,['TEAM-WHEEL-IO','A02','A09','A10','F04'],['GH-WHEELS','GH-PR1-CONFIG','GH-PR1-CONTROLLER'],'original_logic_stubbed_io'),
      ('TEAM11','원본 리프트 위치·리미트 계약 공백',check_lift_feedback_contract,['TEAM-LIFT-WATCHDOG','A03','A08','F22','F27','F28'],['GH-LINEAR'],'original_logic_stubbed_io'),
      ('TEAM12','초음파 선행 큐 비우기의 총 시간 경계',check_echo_drain_bound,['TEAM-SR04-EDGE','A02','A04','F10','F30'],['GH-SR04'],'original_logic_stubbed_io')]
    rows=[]
    for case_id,title,check,requirements,sources,coverage in definitions:
        try:
            status,evidence=check()
        except Exception as exc:
            status,evidence='FAIL',{'error_type':type(exc).__name__,'error':str(exc)}
        rows.append({'id':case_id,'title':title,'passed':status=='PASS','status':status,
                     'requirement_ids':requirements,'evidence':evidence,'coverage_level':coverage,
                     'source_ids':sources,'hardware_accessed':False,'hardware_verified':False})
    rows.append({'id':'TEAM13','title':'실제 센서·구동·위치·하중 검증','passed':False,'status':'NOT_EVALUATED',
                 'requirement_ids':['TEAM-HARDWARE-ACCEPTANCE','TEAM-CAMERA-LIDAR-INTEGRATION','A01','A03','A06','A07','A08','F06','F08','F09','F12','F13','F16','F17','F21','F23','F24','F25','F28','F36'],
                 'evidence':{'reason':'No original hardware imports/main, GPIO, serial, SSH, live sensors, motor outputs, lift, real clock waits or threads were run.'},
                 'coverage_level':'static_source_contract','source_ids':list(EXPECTED_HASHES),
                 'hardware_accessed':False,'hardware_verified':False})
    return rows
