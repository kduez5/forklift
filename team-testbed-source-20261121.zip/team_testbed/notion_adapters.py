"""Run fixed Notion source snapshots with memory-only I/O.

This adapter does not ship private source, load GPIO libraries, open devices,
start a control runtime, or grant motion permission. A source hash mismatch is
NOT_EVALUATED. PASS means only the named synthetic case behaved as expected.
"""
from __future__ import annotations

import ast
import builtins
from hashlib import sha256
from pathlib import Path
import sys
import threading
from types import ModuleType


SOURCE_SPECS = {
    "obstacle": {
        "filename": "3e01cdeb-b6a5-81e5-9283-c5937ce47623_block_01.py",
        "sha256": "db82a37ff9c4d2e161d5d22339e412d14e61be676ed80b4b3019560a9aa7fc65",
        "page_id": "3e01cdeb-b6a5-81e5-9283-c5937ce47623",
        "original_path": "forklift/obstacle.py",
        "imports": frozenset({"dataclasses", "math", "threading", "time"}),
    },
    "loading": {
        "filename": "3e01cdeb-b6a5-81ea-be0c-cae318abc713_block_01.py",
        "sha256": "27c1fab05512ca478bba10aab21e5ee6238e63abc82069a86f0d54d3828cb6c8",
        "page_id": "3e01cdeb-b6a5-81ea-be0c-cae318abc713",
        "original_path": "forklift/loading/machine.py",
        "imports": frozenset({"dataclasses", "math"}),
    },
}
DEFAULT_SOURCE_ROOT = (Path(__file__).resolve().parents[1] / "outputs" /
                       "team_testbed_20261121" / "notion_sources" / "code_snapshots")
_LOAD_LOCK = threading.RLock()


class SourceUnavailable(ValueError):
    pass


def _load_reviewed(name: str, root: Path):
    spec = SOURCE_SPECS[name]
    path = root / spec["filename"]
    if path.is_symlink():
        raise SourceUnavailable("source symlink is not accepted")
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise SourceUnavailable("reviewed source is missing or unreadable") from exc
    if sha256(data).hexdigest() != spec["sha256"]:
        raise SourceUnavailable("source SHA256 does not match reviewed whitelist")
    # Defense in depth: only the fixed, fully reviewed standard-library imports.
    tree = ast.parse(data, filename=spec["filename"])
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules = [n.name for n in node.names]
        elif isinstance(node, ast.ImportFrom):
            modules = [node.module] if node.level == 0 else [None]
        else:
            continue
        if any(n not in spec["imports"] for n in modules):
            raise SourceUnavailable("source import is outside reviewed whitelist")

    def restricted_import(module, globals=None, locals=None, fromlist=(), level=0):
        if level or module not in spec["imports"]:
            raise ImportError("import not permitted by reviewed source contract")
        return builtins.__import__(module, globals, locals, fromlist, level)

    module_name = "_team_testbed_reviewed_notion_" + name
    module = ModuleType(module_name)
    module.__dict__["__builtins__"] = {**vars(builtins), "__import__": restricted_import}
    # Fixed source has no top-level I/O; keep module registration temporary for
    # dataclass annotation processing. This is a hash whitelist, not a sandbox
    # for arbitrary user-supplied programs.
    with _LOAD_LOCK:
        previous = sys.modules.get(module_name)
        sys.modules[module_name] = module
        try:
            exec(compile(tree, spec["filename"], "exec"), module.__dict__)
        finally:
            if previous is None:
                sys.modules.pop(module_name, None)
            else:
                sys.modules[module_name] = previous
    return module


class _Clock:
    def __init__(self, now=1.0):
        self.now = now

    def __call__(self):
        return self.now


class _MemoryDrive:
    def __init__(self):
        self.commands = []

    def command(self, linear, angular):
        self.commands.append((linear, angular))

    def stop(self):
        self.commands.append((0.0, 0.0))


def _guard(mod):
    clock, drive = _Clock(), _MemoryDrive()
    guard = mod.ObstacleGuard(drive, clock=clock)
    guard.set_active(True)
    return guard, drive, clock


def _require(condition, reason):
    if not condition:
        raise AssertionError(reason)


def _missing_and_stale(mod):
    guard, drive, clock = _guard(mod)
    guard.command(.1, 0.)
    _require(drive.commands[-1] == (0., 0.), "missing sample permitted motion")
    guard.submit(1., .5, token=guard.token())
    guard.command(.1, 0.)
    _require(drive.commands[-1] == (.1, 0.), "fresh synthetic sample not accepted")
    clock.now = 1.3
    guard.command(.1, 0.)
    _require(drive.commands[-1] == (0., 0.) and guard.status["blocked"], "stale sample did not stop")
    return {"requested": [.1, 0.], "after_stale": drive.commands[-1], "status": guard.status}


def _sudden_approach(mod):
    guard, drive, clock = _guard(mod)
    guard.submit(1., .3)
    clock.now = 1.1
    guard.submit(1.1, .08)
    guard.command(.1, 0.)
    _require(guard.status["blocked"] and drive.commands[-1] == (0., 0.), "sudden approach not held")
    _require(guard.finish() is False, "arrival allowed during hold")
    return {"samples": [[1., .3], [1.1, .08]], "status": guard.status, "finish": False}


def _invalid_samples(mod):
    outcomes = []
    for label, stamp, distance in [("duplicate", 1., .5), ("future", 1.2, .5),
                                   ("no_echo", 1.1, None), ("nonfinite", 1.1, float("inf"))]:
        guard, drive, clock = _guard(mod)
        guard.submit(1., .5)
        clock.now = 1.1
        guard.submit(stamp, distance)
        guard.command(.1, 0.)
        _require(guard.status["blocked"] and drive.commands[-1] == (0., 0.), label + " did not block")
        outcomes.append({"fault": label, "state": guard.status["state"]})
    guard, _, _ = _guard(mod)
    token = guard.token()
    guard.set_active(True)
    _require(guard.submit(1., .5, token=token) is False, "old activation token accepted")
    return {"faults": outcomes, "old_activation_token_rejected": True}


def _automatic_clear_conflict(mod):
    guard, drive, clock = _guard(mod)
    guard.submit(1., .3)
    clock.now = 1.1
    guard.submit(clock.now, .08)
    for i in range(53):
        clock.now = 1.2 + i / 10
        guard.submit(clock.now, .5)
    guard.command(.1, 0.)
    _require(not guard.status["blocked"] and drive.commands[-1] == (.1, 0.),
             "reviewed automatic-clear behavior changed")
    return {"observed": "clear dwell releases hold; new planner command reaches memory drive without RESET/ACK/ARM",
            "current_integration_contract": "protective stop requires separate RESET acknowledgment and ARM",
            "conflict_confirmed": True, "memory_output": drive.commands[-1]}


def _gradual_close_conflict(mod):
    guard, drive, clock = _guard(mod)
    for i, distance in enumerate([.12, .11, .10, .09, .08]):
        clock.now = 1. + i / 10
        guard.submit(clock.now, distance)
    guard.command(.1, 0.)
    _require(not guard.status["blocked"] and drive.commands[-1] == (.1, 0.),
             "reviewed gradual-approach behavior changed")
    return {"observed": "gradual crossing of 0.10m threshold does not trigger sudden-approach guard",
            "current_integration_contract": "independent absolute clearance/envelope gate is still required",
            "conflict_confirmed": True, "last_distance_m": .08, "memory_output": drive.commands[-1]}


def _machine(mod):
    return mod.LoadingMachine("123", mod.LoadingSettings(arrival_distance_m=.1, reverse_duration_s=5.), now=0.)


def _tick(mod, machine, now, sequence, *, distance=.5, yaw=0., rear=True, rotation=True, code="123", **kw):
    sample = mod.Sample(yaw, now, distance, now, rear, rotation)
    vision = mod.Vision(now, sequence, code)
    return machine.tick(now, sample, vision, **kw)


def _approaching(mod):
    machine = _machine(mod)
    for i in range(3):
        action = _tick(mod, machine, i / 10, i + 1)
    _require(action.state == "APPROACHING", "three distinct target frames did not reach approach")
    return machine


def _waiting_fork(mod):
    machine = _approaching(mod)
    starts = []
    for i in range(3, 6):
        starts.append(_tick(mod, machine, i / 10, i + 1, distance=.09).fork_start)
    _require(starts == [False, False, True] and machine.state == "WAIT_FORK", "arrival did not require three samples")
    return machine


def _normal_loading(mod):
    machine = _waiting_fork(mod)
    action = _tick(mod, machine, .6, 7, distance=.09, fork_complete=True)
    _require(action.state == "REVERSING" and not action.fork_start, "fork acknowledgment not consumed")
    moving_ticks = 0
    for i in range(53):
        action = _tick(mod, machine, .7 + i / 10, i + 8, distance=.5)
        moving_ticks += action.linear < 0
        if action.complete:
            break
    _require(action.complete and action.linear == 0. and action.angular == 0., "synthetic retreat did not finish stopped")
    return {"terminal_state": action.state, "reverse_ticks": moving_ticks,
            "arrival_samples": 3, "target_frames": 3, "physical_lift_position_proven": False,
            "assumed_arrival_distance_m": .1, "assumed_retreat_duration_s": 5.}


def _invalid_front(mod):
    outcomes = []
    for distance in (None, 0., float("inf")):
        machine = _approaching(mod)
        action = _tick(mod, machine, .3, 4, distance=distance)
        _require(action.state == "FAILED" and not action.fork_start and action.linear == 0., "invalid range treated as arrival")
        outcomes.append(action.error)
    return {"invalid_front_cases": ["None", "zero", "infinity"], "errors": outcomes}


def _vision_order(mod):
    machine = _machine(mod)
    _tick(mod, machine, 0., 1)
    _tick(mod, machine, .1, 1)
    _require(machine.target_count == 1 and machine.state == "SCANNING", "duplicate camera frame counted twice")
    _tick(mod, machine, .2, 2)
    action = _tick(mod, machine, .3, 1)
    _require(action.state == "FAILED" and "backwards" in action.error, "camera rollback accepted")
    return {"duplicate_did_not_increment": True, "rollback_error": action.error}


def _pose_and_rear(mod):
    machine = _approaching(mod)
    action = _tick(mod, machine, .3, 4, yaw=None)
    _require(action.state == "SENSOR_WAIT" and action.linear == action.angular == 0., "unknown yaw did not wait")
    for i in range(4, 25):
        action = _tick(mod, machine, i / 10, i + 1, yaw=None)
    _require(action.state == "FAILED" and "recovery timeout" in action.error, "pose recovery did not expire")
    pose_error = action.error
    machine = _waiting_fork(mod)
    _tick(mod, machine, .6, 7, distance=.09, fork_complete=True)
    action = _tick(mod, machine, .7, 8, rear=None)
    _require(action.state == "FAILED" and action.linear == 0., "unknown rear clearance allowed retreat")
    return {"pose_error": pose_error, "rear_error": action.error}


def _fork_and_clock_faults(mod):
    machine = _waiting_fork(mod)
    timeout = _tick(mod, machine, 31., 7)
    _require(timeout.state == "FAILED" and "fork completion timeout" in timeout.error, "missing fork ACK did not time out")
    machine = _approaching(mod)
    rollback = _tick(mod, machine, .1, 4)
    _require(rollback.state == "FAILED" and "clock discontinuity" in rollback.error, "clock rollback accepted")
    machine = _approaching(mod)
    stalled = _tick(mod, machine, .5, 4)
    _require(stalled.state == "FAILED" and "stalled" in stalled.error, "moving loop gap accepted")
    return {"fork_timeout": timeout.error, "clock_rollback": rollback.error, "moving_loop_gap": stalled.error}


_CASES = (
    ("N01", "obstacle", "Missing and stale ultrasound block memory output", _missing_and_stale, False, ["TEAM-NOTION-OBSTACLE", "A02", "A07"]),
    ("N02", "obstacle", "Sudden approach holds output and arrival", _sudden_approach, False, ["TEAM-NOTION-OBSTACLE", "A07"]),
    ("N03", "obstacle", "Invalid timestamps, no echo and old generation", _invalid_samples, False, ["TEAM-NOTION-OBSTACLE", "A02"]),
    ("N04", "obstacle", "Automatic clear conflicts with explicit re-arm policy", _automatic_clear_conflict, True, ["TEAM-NOTION-OBSTACLE", "TEAM-NOTION-SAFETY", "A07", "A10"]),
    ("N05", "obstacle", "Gradual close approach needs an absolute clearance gate", _gradual_close_conflict, True, ["TEAM-NOTION-OBSTACLE", "A07"]),
    ("N06", "loading", "Distinct target and range samples to synthetic loading completion", _normal_loading, False, ["TEAM-NOTION-LOADING", "A04", "A10"]),
    ("N07", "loading", "No echo and invalid distance are never arrival", _invalid_front, False, ["TEAM-NOTION-LOADING", "A02", "A04"]),
    ("N08", "loading", "Camera duplicate and sequence rollback", _vision_order, False, ["TEAM-NOTION-LOADING", "A02"]),
    ("N09", "loading", "Unknown pose and rear clearance stop progress", _pose_and_rear, False, ["TEAM-NOTION-LOADING", "A03", "A04"]),
    ("N10", "loading", "Missing fork ACK, clock rollback and stalled moving loop", _fork_and_clock_faults, False, ["TEAM-NOTION-LOADING", "A04", "A07"]),
)


def run_notion_checks(source_root: Path | None = None) -> list[dict]:
    """Run 10 narrow checks against local, hash-pinned Notion snapshots.

    Missing private sources are expected on a public clone: results remain
    NOT_EVALUATED until the team provides the exact authenticated source pack.
    CONTRACT_CONFLICT is not a pass and is never hidden by a green total.
    """
    root = Path(source_root) if source_root is not None else DEFAULT_SOURCE_ROOT
    modules, errors = {}, {}
    for name in SOURCE_SPECS:
        try:
            modules[name] = _load_reviewed(name, root)
        except Exception as exc:
            errors[name] = f"{type(exc).__name__}: {exc}"
    results = []
    for identifier, name, title, check, conflict, requirements in _CASES:
        spec = SOURCE_SPECS[name]
        row = {"id": identifier, "title": title, "status": "NOT_EVALUATED", "passed": False,
               "requirement_ids": requirements, "coverage_level": "original_logic_stubbed_io",
               "source_ids": [spec["page_id"]], "evidence": {"source_sha256": spec["sha256"],
               "original_path": spec["original_path"], "physical_actuation_count": 0,
               "actual_motion_permission": False, "actuator_io": "memory-only"}}
        if identifier == "N04":
            row["source_ids"].append("3e01cdeb-b6a5-8053-88b1-f0f8c9e3fdb7")
        elif identifier == "N05":
            row["source_ids"].append("41f1cdeb-b6a5-81df-b891-d81c66aec43b")
        if name in errors:
            row["coverage_level"] = "static_source_contract"
            row["evidence"]["not_evaluated_reason"] = errors[name]
        else:
            try:
                row["evidence"].update(check(modules[name]))
                row["status"] = "CONTRACT_CONFLICT" if conflict else "PASS"
                row["passed"] = not conflict
            except Exception as exc:
                row["status"] = "FAIL"
                row["evidence"]["error"] = f"{type(exc).__name__}: {exc}"
        results.append(row)
    return results
