"""Trace evidence without equating a passing example with full acceptance."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

DATA = Path(__file__).with_name('data')
STATUSES = {'PASS', 'FAIL', 'NOT_EVALUATED', 'CONTRACT_CONFLICT'}

# Reviewed independently of the JSON rows: a deleted row must not delete its
# own expectation. Additions require review, but never replace these IDs.
CORE_IDS = frozenset({f'{p}{i:02}' for p, count in [('A', 10), ('F', 37), ('S', 10), ('T', 10)]
                      for i in range(1, count + 1)} | {f'G{i}' for i in range(10)})
MANUAL_IDS = frozenset('MANUAL-' + name for name in (
    'M01', 'M02', 'M03', 'M04', 'M05', 'S01', 'S02', 'P01', 'N01',
    'L01', 'L02', 'L03', 'D01', 'A01'))
NOTION_IDS = frozenset('TEAM-NOTION-' + name for name in (
    'OBSTACLE', 'LOADING', 'UNLOADING', 'MOTORS', 'LIFT', 'ULTRASONIC4',
    'SAFETY', 'VISION', 'LIDAR', 'PATH', 'TASK', 'DB', 'RUNTIME-LEASE',
    'PID', 'QR', 'ARUCO', 'NFC', 'INTEGRATION', 'WORKORDER'))
GIT_IDS = frozenset('TEAM-' + name for name in (
    'SOURCE-PROVENANCE', 'WHEEL-IO', 'MANUAL-LEASE', 'LIFT-WATCHDOG',
    'SR04-EDGE', 'PIN-CONFLICT', 'HARDWARE-ACCEPTANCE', 'CAMERA-LIDAR-INTEGRATION'))
REQUIRED_BY_FILE = {
    'requirements.json': CORE_IDS | MANUAL_IDS,
    'notion_requirements.json': NOTION_IDS,
    'git_requirements.json': GIT_IDS,
}
REQUIRED_IDS = frozenset().union(*REQUIRED_BY_FILE.values())


def validate_registry(registry, required_ids=REQUIRED_IDS):
    if not isinstance(registry, dict) or not isinstance(registry.get('requirements'), list):
        raise ValueError('Registry must contain a requirement list')
    ids = []
    for row in registry['requirements']:
        if (not isinstance(row, dict) or not isinstance(row.get('id'), str)
                or not row['id'].strip() or not isinstance(row.get('title'), str)):
            raise ValueError('Every requirement needs a string ID and title')
        ids.append(row['id'])
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate requirement IDs')
    missing = set(required_ids) - set(ids)
    if missing:
        raise ValueError('Missing mandatory requirements: ' + repr(sorted(missing)))
    return set(ids)


def load_registry(data_dir=None):
    directory = Path(data_dir) if data_dir is not None else DATA
    base, snapshots = None, {}
    for name, expected in REQUIRED_BY_FILE.items():
        path = directory / name
        if not path.is_file():
            raise ValueError('Missing mandatory registry file: ' + name)
        raw = path.read_bytes()
        document = json.loads(raw)
        if (not isinstance(document, dict) or type(document.get('schema_version')) is not int
                or document['schema_version'] != 1):
            raise ValueError('Invalid registry schema: ' + name)
        validate_registry(document, expected)
        if base is None:
            base = document
        else:
            base['requirements'].extend(document['requirements'])
        snapshots[name] = hashlib.sha256(raw).hexdigest()
    validate_registry(base)
    base['registry_file_sha256'] = snapshots
    return base


def trace_requirements(registry, cases):
    known = validate_registry(registry)
    if not isinstance(cases, list):
        raise ValueError('Cases must be a list')
    seen = set()
    for case in cases:
        if not isinstance(case, dict) or not isinstance(case.get('id'), str) or not case['id'].strip():
            raise ValueError('Case needs a nonempty string ID')
        if case['id'] in seen:
            raise ValueError('Duplicate case: ' + case['id'])
        seen.add(case['id'])
        status = case.get('status')
        if not isinstance(status, str) or status not in STATUSES:
            raise ValueError('Unknown status')
        if 'passed' not in case:
            raise ValueError('Case needs an explicit passed value')
        passed = case['passed']
        if ((status == 'PASS' and passed is not True)
                or (status == 'FAIL' and passed is not False)
                or (status in ('NOT_EVALUATED', 'CONTRACT_CONFLICT') and passed is not False and passed is not None)):
            raise ValueError('Status and passed disagree for ' + case['id'])
        tags = case.get('requirement_ids')
        if (not isinstance(tags, list) or not tags
                or any(not isinstance(tag, str) or not tag for tag in tags)
                or len(tags) != len(set(tags))):
            raise ValueError('Case needs nonempty, unique requirement IDs')
        unknown = set(tags) - known
        if unknown:
            raise ValueError('Unregistered requirements: ' + repr(sorted(unknown)))
    result = []
    for requirement in registry['requirements']:
        linked = [c for c in cases if requirement['id'] in c.get('requirement_ids', [])]
        tested = [c for c in linked if c['status'] in ('PASS', 'FAIL', 'CONTRACT_CONFLICT')]
        states = {c['status'] for c in linked}
        coverage = ('CONTRACT_CONFLICT' if 'CONTRACT_CONFLICT' in states else
                    'FAILING_EXAMPLES' if 'FAIL' in states else
                    'PARTIAL_OFFLINE_EVIDENCE' if tested else 'NOT_EVALUATED')
        result.append({**requirement, 'case_ids': [c['id'] for c in linked],
                       'tested_examples': len(tested), 'coverage_status': coverage,
                       'coverage_levels': sorted({c.get('coverage_level', 'unspecified') for c in tested}),
                       'full_acceptance_verified': False,
                       'physical_acceptance': 'NOT_EVALUATED'})
    return result


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

