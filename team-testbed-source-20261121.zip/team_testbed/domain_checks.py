"""Offline domain-contract validators, not robot controllers or sensor models.

Only standard-library arithmetic and an in-memory SQLite ledger are used. No
team module is imported, no process/device is opened, and motion permission is
never produced. Geometry is SE(2) only; real measurements remain unevaluated.
These are validation oracles, not production safety logic or movement authority.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import json
import math
import sqlite3


def _number(value):
    return type(value) in (int, float) and math.isfinite(value)


def _identity(value):
    return isinstance(value, str) and bool(value.strip())


@dataclass(frozen=True)
class Transform2D:
    parent: str
    child: str
    rotation: tuple = ((1.0, 0.0), (0.0, 1.0))
    translation: tuple = (0.0, 0.0)
    length_unit: str = "m"
    angle_unit: str = "rad"
    calibration_version: str = "fixture-v1"

    @classmethod
    def yaw(cls, parent, child, angle, translation=(0.0, 0.0), **kwargs):
        if not _number(angle):
            raise ValueError("Yaw must be finite radians")
        c, s = math.cos(angle), math.sin(angle)
        return cls(parent, child, ((c, -s), (s, c)), translation, **kwargs)

    def validate(self):
        if not all(_identity(x) for x in (self.parent, self.child, self.calibration_version)) or self.parent == self.child:
            raise ValueError("Distinct named parent/child and calibration version required")
        if self.length_unit != "m" or self.angle_unit != "rad":
            raise ValueError("Canonical m/rad units required; no implicit conversion")
        try:
            if len(self.rotation) != 2 or any(len(row) != 2 for row in self.rotation) or len(self.translation) != 2:
                raise ValueError("SE2 requires a 2x2 rotation and 2D translation")
            a, b = self.rotation[0]; c, d = self.rotation[1]
        except (TypeError, IndexError) as exc:
            raise ValueError("Malformed transform") from exc
        if not all(_number(x) for x in (a, b, c, d, *self.translation)):
            raise ValueError("Nonfinite or nonnumeric transform")
        if abs(a*d-b*c-1) > 1e-8:
            raise ValueError("Rotation determinant must be +1; reflection/scale is forbidden")
        if max(abs(a*a+c*c-1), abs(b*b+d*d-1), abs(a*b+c*d)) > 1e-8:
            raise ValueError("Rotation must be orthonormal")

    def apply(self, point):
        self.validate()
        if not isinstance(point, (tuple, list)) or len(point) != 2 or not all(_number(x) for x in point):
            raise ValueError("Finite 2D point required")
        r = self.rotation
        return (r[0][0]*point[0]+r[0][1]*point[1]+self.translation[0],
                r[1][0]*point[0]+r[1][1]*point[1]+self.translation[1])

    def inverse(self):
        self.validate()
        r, t = self.rotation, self.translation
        transpose = ((r[0][0], r[1][0]), (r[0][1], r[1][1]))
        shift = (-(transpose[0][0]*t[0]+transpose[0][1]*t[1]),
                 -(transpose[1][0]*t[0]+transpose[1][1]*t[1]))
        return Transform2D(self.child, self.parent, transpose, shift, calibration_version=self.calibration_version)


class FrameGraph:
    """A rooted transform tree with one parent per child, not arbitrary SE3."""
    def __init__(self, root, transforms):
        if not _identity(root):
            raise ValueError("Named root required")
        self.root, self.by_child = root, {}
        for transform in transforms:
            if not isinstance(transform, Transform2D):
                raise ValueError("Transform2D required")
            transform.validate()
            if transform.child in self.by_child or transform.child == root:
                raise ValueError("Multiple parents or a parented root")
            self.by_child[transform.child] = transform
        for child in self.by_child:
            node, seen = child, set()
            while node != root:
                if node in seen:
                    raise ValueError("Cyclic frame graph")
                seen.add(node)
                if node not in self.by_child:
                    raise ValueError("Disconnected or missing parent frame: " + node)
                node = self.by_child[node].parent

    def _chain(self, frame):
        if not _identity(frame) or frame != self.root and frame not in self.by_child:
            raise ValueError("Unknown frame: " + str(frame))
        chain = []
        while frame != self.root:
            transform = self.by_child[frame]
            chain.append(transform)
            frame = transform.parent
        return chain

    def transform(self, point, source, target):
        if not isinstance(point, (tuple, list)) or len(point) != 2 or not all(_number(x) for x in point):
            raise ValueError("Finite 2D point required even for an identity transform")
        transformed = point
        for transform in self._chain(source):
            transformed = transform.apply(transformed)
        for transform in reversed(self._chain(target)):
            transformed = transform.inverse().apply(transformed)
        return transformed


@dataclass(frozen=True)
class Envelope2D:
    xmin: float
    ymin: float
    xmax: float
    ymax: float
    version: str = "fixture-envelope-v1"

    def validate(self):
        if (not all(_number(x) for x in (self.xmin, self.ymin, self.xmax, self.ymax))
                or self.xmin >= self.xmax or self.ymin >= self.ymax or not _identity(self.version)):
            raise ValueError("Finite nonempty conservative envelope required")

    def contains(self, other):
        self.validate(); other.validate()
        return self.xmin <= other.xmin and self.ymin <= other.ymin and self.xmax >= other.xmax and self.ymax >= other.ymax

    def corners(self):
        self.validate()
        return ((self.xmin, self.ymin), (self.xmax, self.ymin), (self.xmax, self.ymax), (self.xmin, self.ymax))


def conservative_envelope(components, *, uncertainty_m, margin_m, version="fixture-envelope-v1"):
    if any(not _number(x) or x < 0 for x in (uncertainty_m, margin_m)):
        raise ValueError("Nonnegative finite uncertainty/margin required")
    points = [point for component in components for point in component]
    if not points or any(len(point) != 2 or not all(_number(x) for x in point) for point in points):
        raise ValueError("Explicit finite 2D component points required")
    expansion = uncertainty_m + margin_m
    result = Envelope2D(min(p[0] for p in points)-expansion, min(p[1] for p in points)-expansion,
                        max(p[0] for p in points)+expansion, max(p[1] for p in points)+expansion, version)
    result.validate()
    return result


def rotation_sweep_bound(envelope):
    """Circle/AABB containing every planar rotation about the base origin."""
    radius = max(math.hypot(x, y) for x, y in envelope.corners())
    return {"radius_m": radius, "bounds": [-radius, -radius, radius, radius],
            "scope": "conservative_full_rotation_SE2_only", "height_collision_evaluated": False}


def accept_envelope_update(current, candidate, *, moving, independent_measurement_verified):
    if type(moving) is not bool or type(independent_measurement_verified) is not bool:
        raise ValueError("Explicit boolean update conditions required")
    current.validate(); candidate.validate()
    enlarges = candidate.contains(current)
    if enlarges:
        return {"accepted": True, "reason": "conservative_enlargement", "actual_motion_permission": False}
    accepted = not moving and independent_measurement_verified and candidate.version != current.version
    return {"accepted": accepted, "reason": "stopped_verified_new_version" if accepted else "shrink_or_shift_requires_stopped_independent_measurement_and_new_version",
            "actual_motion_permission": False}


def stopping_distance_model(speed_mps, latency_s, minimum_deceleration_mps2, uncertainty_m, *, bounds_verified=False):
    values = (speed_mps, latency_s, minimum_deceleration_mps2, uncertainty_m)
    if (not all(_number(x) for x in values) or latency_s < 0 or minimum_deceleration_mps2 <= 0
            or uncertainty_m < 0 or bounds_verified is not True):
        return {"status": "UNKNOWN", "distance_m": None, "reason": "missing_or_invalid_model_bounds",
                "actual_motion_permission": False, "physical_validation": False}
    distance = abs(speed_mps)*latency_s + speed_mps**2/(2*minimum_deceleration_mps2) + uncertainty_m
    return {"status": "ASSUMED_MODEL", "distance_m": distance, "physical_validation": False,
            "reason": "formula_under_supplied_bounds_not_a_measured_stop", "actual_motion_permission": False}


def lift_evidence_status(*, reference_verified=False, reference_id=None, limit_evidence_id=None,
                         reference_session=None, current_session=None, lower_limit=None, upper_limit=None,
                         position_interval_m=None, manual_position_changed=False):
    result = {"status": "UNKNOWN", "position_interval_m": None, "blocked_directions": ["up", "down"],
              "actual_motion_permission": False, "position_basis": "supplied_evidence_not_measured_here"}
    if type(lower_limit) is not bool or type(upper_limit) is not bool:
        return {**result, "reason": "limit_health_or_state_unknown"}
    if lower_limit and upper_limit:
        return {**result, "status": "CONFLICT", "reason": "both_limits_active"}
    if (reference_verified is not True or not _identity(reference_id) or not _identity(limit_evidence_id)
            or not _identity(current_session) or reference_session != current_session or manual_position_changed is not False):
        return {**result, "reason": "reference_missing_obsolete_or_manually_changed"}
    if (not isinstance(position_interval_m, (tuple, list)) or len(position_interval_m) != 2
            or not all(_number(x) for x in position_interval_m)
            or not 0 <= position_interval_m[0] <= position_interval_m[1]):
        return {**result, "reason": "height_interval_missing_or_invalid"}
    blocked = (["down"] if lower_limit else []) + (["up"] if upper_limit else [])
    return {**result, "status": "EVIDENCE_CONSISTENT", "position_interval_m": list(position_interval_m),
            "blocked_directions": blocked, "reason": "reference_and_limits_consistent_only"}


STAGES = ("IDENTIFY", "LOCALIZE", "APPROACH", "ALIGN", "INSERT", "LIFT", "VERIFY_LOAD",
          "TRANSPORT", "ALIGN_DROP", "LOWER", "VERIFY_SUPPORT", "WITHDRAW", "VERIFY_RELEASE", "COMPLETE")
STAGE_KIND = dict(zip(STAGES, ("identity_verified", "pose_verified", "approach_reached", "alignment_verified",
    "insertion_verified", "lift_motion_verified", "load_supported", "destination_reached", "drop_alignment_verified",
    "lower_motion_verified", "support_load_transfer", "withdraw_path_and_motion_verified", "fork_release_verified", "placement_stable")))
INDEPENDENT_STAGES = {"VERIFY_LOAD", "VERIFY_SUPPORT", "VERIFY_RELEASE", "COMPLETE"}


@dataclass(frozen=True)
class MissionEvidence:
    task_id: str
    object_id: str
    stage: str
    kind: str
    evidence_id: str
    source_id: str
    session_id: str
    verified: bool = False
    independent: bool = False
    command_ack_only: bool = False


class EvidenceMission:
    """Sequence/identity/evidence checker, with no motion command generation."""
    def __init__(self, task_id, object_id, session_id):
        if not all(_identity(x) for x in (task_id, object_id, session_id)):
            raise ValueError("Explicit task/object/session IDs required")
        self.task_id, self.object_id, self.session_id = task_id, object_id, session_id
        self.stage, self.evidence_ids = "IDLE", set()
        self.events = []

    def advance(self, evidence):
        expected_index = 0 if self.stage == "IDLE" else STAGES.index(self.stage)+1
        if expected_index >= len(STAGES):
            raise ValueError("Mission already completed; duplicate completion is not a new event")
        expected = STAGES[expected_index]
        if not isinstance(evidence, MissionEvidence) or evidence.stage != expected:
            raise ValueError("Out-of-order mission evidence; expected " + expected)
        if (evidence.task_id != self.task_id or evidence.object_id != self.object_id or evidence.session_id != self.session_id
                or not _identity(evidence.evidence_id) or not _identity(evidence.source_id)):
            raise ValueError("Task, object, session or evidence identity mismatch")
        if evidence.evidence_id in self.evidence_ids:
            raise ValueError("An evidence event cannot be recycled into another stage")
        if evidence.verified is not True or evidence.command_ack_only is not False or evidence.kind != STAGE_KIND[expected]:
            raise ValueError("Stage requires verified outcome evidence, not command acknowledgement")
        if expected in INDEPENDENT_STAGES and evidence.independent is not True:
            raise ValueError("Independent outcome evidence required")
        self.evidence_ids.add(evidence.evidence_id)
        self.stage = expected
        self.events.append({"stage": expected, "evidence_id": evidence.evidence_id, "source_id": evidence.source_id,
                            "scope": "synthetic_contract", "physical_completion_verified": False})
        return {"stage": self.stage, "synthetic_complete": self.stage == "COMPLETE",
                "physical_completion_verified": False, "actual_motion_permission": False}


class EvidenceLedger:
    """Actual SQLite uniqueness/transactions in RAM, not a production inventory."""
    def __init__(self):
        self.db = sqlite3.connect(":memory:")
        self.db.execute("CREATE TABLE tasks(task_id TEXT PRIMARY KEY, object_id TEXT NOT NULL, destination TEXT NOT NULL, state TEXT NOT NULL)")
        self.db.execute("CREATE TABLE rewards(task_id TEXT NOT NULL, stage TEXT NOT NULL, evidence_id TEXT NOT NULL, amount REAL NOT NULL, PRIMARY KEY(task_id,stage), UNIQUE(task_id,evidence_id))")

    def request(self, task_id, object_id, destination):
        if not all(_identity(x) for x in (task_id, object_id, destination)):
            raise ValueError("Nonempty task/object/destination IDs required")
        row = self.db.execute("SELECT object_id,destination,state FROM tasks WHERE task_id=?", (task_id,)).fetchone()
        if row:
            if row[:2] != (object_id, destination):
                raise ValueError("Duplicate task ID with conflicting payload")
            return {"created": False, "state": row[2], "physical_complete": False}
        with self.db:
            self.db.execute("INSERT INTO tasks VALUES(?,?,?,'REQUESTED')", (task_id, object_id, destination))
        return {"created": True, "state": "REQUESTED", "physical_complete": False}

    def award_stage(self, mission, stage, amount=1.0):
        if not _number(amount) or amount < 0:
            raise ValueError("Finite nonnegative reward required")
        if stage == "COMPLETE":
            raise ValueError("Completion reward is committed atomically with the task, not through award_stage")
        events = [event for event in mission.events if event["stage"] == stage]
        row = self.db.execute("SELECT object_id FROM tasks WHERE task_id=?", (mission.task_id,)).fetchone()
        if not events or row is None or row[0] != mission.object_id:
            raise ValueError("Registered task and verified stage outcome required for reward")
        if self.db.execute("SELECT 1 FROM rewards WHERE task_id=? AND stage=?", (mission.task_id, stage)).fetchone():
            return 0.0
        with self.db:
            self.db.execute("INSERT INTO rewards VALUES(?,?,?,?)", (mission.task_id, stage, events[0]["evidence_id"], amount))
        return amount

    def commit_synthetic_completion(self, mission):
        if mission.stage != "COMPLETE":
            raise ValueError("A request or command ACK does not establish task completion")
        row = self.db.execute("SELECT object_id,state FROM tasks WHERE task_id=?", (mission.task_id,)).fetchone()
        if row is None or row[0] != mission.object_id:
            raise ValueError("Completion identity does not match the recorded task")
        if row[1] == "SYNTHETIC_COMPLETE":
            return {"new_completion": False, "physical_complete": False, "task_bonus": 0.0}
        with self.db:
            self.db.execute("UPDATE tasks SET state='SYNTHETIC_COMPLETE' WHERE task_id=?", (mission.task_id,))
            # One completion bonus uses the verified COMPLETE stage's unique key.
            event = mission.events[-1]
            inserted = self.db.execute("INSERT OR IGNORE INTO rewards VALUES(?,?,?,?)",
                                       (mission.task_id, "COMPLETE", event["evidence_id"], 10.0)).rowcount
        return {"new_completion": True, "physical_complete": False, "task_bonus": 10.0 if inserted else 0.0}

    def close(self):
        self.db.close()


def diagnose_motion(*, symptom, stop_reason=None, voltage_v=None, voltage_min_v=None,
                    voltage_measurement_verified=False, observed_motion_m=None, current_a=None):
    """Evidence ranking only; never converts symptoms to a confirmed root cause."""
    recognized = ("input_deadline_expired", "operator_stop", "sensor_stale", "estop_latched")
    if stop_reason in recognized:
        return {"classification": "recorded_protective_stop", "root_cause_confirmed": False,
                "hypotheses": [{"name": stop_reason, "status": "REPORTED_STOP_REASON"}],
                "pwm_increase_recommended": False, "automatic_patch_applied": False}
    hypotheses = [{"name": name, "status": "UNRESOLVED"} for name in
                  ("power_or_wiring", "mechanical_friction_or_jam", "command_mapping_or_timing", "motion_observation_error")]
    if (voltage_measurement_verified is True and _number(voltage_v) and voltage_v >= 0
            and _number(voltage_min_v) and voltage_min_v > 0 and voltage_v < voltage_min_v):
        hypotheses[0] = {"name": "low_voltage_observed", "status": "SUPPORTED_SYMPTOM_NOT_PROVEN_CAUSE",
                         "voltage_v": voltage_v, "threshold_v": voltage_min_v}
    return {"classification": "multiple_hypotheses", "symptom": symptom, "hypotheses": hypotheses,
            "root_cause_confirmed": False, "additional_measurements": ["synchronized_voltage_current", "applied_command", "independent_motion_observation", "stopped_mechanical_inspection"],
            "pwm_increase_recommended": False, "automatic_patch_applied": False}


@dataclass(frozen=True)
class OfflinePermit:
    generation: int
    session_id: str
    issued_at_s: float
    expires_at_s: float


class OfflinePermitContract:
    """A no-output model of lifecycle ordering; not an authorization provider."""
    def __init__(self, session_id="fixture-session"):
        if not _identity(session_id):
            raise ValueError("Session required")
        self.session_id, self.generation = session_id, 0
        self.state, self.clear_observed = "STOPPED", False
        self.permit, self.goal_id, self.last_sequence = None, None, -1
        self.used_goal_ids = set()

    def stop(self):
        self.generation += 1
        self.state, self.clear_observed = "STOPPED", False
        self.permit, self.goal_id, self.last_sequence = None, None, -1

    def clear(self, verified):
        if verified is not True:
            raise ValueError("Verified clear evidence required")
        self.clear_observed = True
        return self.state

    def reset(self, generation, explicit=True):
        if type(generation) is not int or generation != self.generation or explicit is not True or self.state != "STOPPED" or not self.clear_observed:
            raise ValueError("Fresh explicit RESET after clear required")
        self.generation += 1
        self.state = "RESET"

    def ack(self, generation):
        if type(generation) is not int or self.state != "RESET" or generation != self.generation:
            raise ValueError("ACK must follow current RESET")
        self.state = "ACKNOWLEDGED"

    def arm(self, generation, now_s, ttl_s=.3):
        if type(generation) is not int or self.state != "ACKNOWLEDGED" or generation != self.generation:
            raise ValueError("ARM must follow current ACK")
        if not _number(now_s) or now_s < 0 or not _number(ttl_s) or not 0 < ttl_s <= .3:
            raise ValueError("Bounded finite offline permit lifetime required")
        self.permit = OfflinePermit(self.generation, self.session_id, now_s, now_s+ttl_s)
        self.state = "ARMED"
        return self.permit

    def _verify(self, permit, now_s):
        if (not isinstance(permit, OfflinePermit) or permit != self.permit
                or permit.generation != self.generation or permit.session_id != self.session_id
                or not _number(now_s) or not permit.issued_at_s <= now_s < permit.expires_at_s):
            raise ValueError("Expired, obsolete or foreign offline permit")

    def new_goal(self, goal_id, permit, now_s):
        self._verify(permit, now_s)
        if self.state != "ARMED" or not _identity(goal_id) or goal_id in self.used_goal_ids:
            raise ValueError("A distinct new goal after ARM is required")
        self.goal_id = goal_id; self.used_goal_ids.add(goal_id)
        self.state = "GOAL_READY"

    def check_intent(self, permit, sequence, now_s):
        self._verify(permit, now_s)
        if self.state != "GOAL_READY" or type(sequence) is not int or sequence <= self.last_sequence:
            raise ValueError("Fresh ordered intent requires a new goal")
        self.last_sequence = sequence
        return {"synthetic_contract_accepted": True, "actual_motion_permission": False}

    def refresh_health(self):
        return {"state": self.state, "permit_expiry_unchanged": self.permit.expires_at_s if self.permit else None,
                "actual_motion_permission": False}


def _expect_rejection(operation):
    try:
        operation()
    except ValueError as exc:
        return {"rejected": True, "reason": str(exc)}
    raise AssertionError("Expected explicit rejection but operation succeeded")


def _check(condition, **evidence):
    if not condition:
        raise AssertionError(json.dumps(evidence, ensure_ascii=False))
    return evidence


def _mission(until="COMPLETE"):
    mission = EvidenceMission("task-fixture-1", "box-fixture-1", "fixture-session")
    for stage in STAGES:
        mission.advance(MissionEvidence(mission.task_id, mission.object_id, stage, STAGE_KIND[stage],
                        "event-"+stage, "independent-fixture-observer", mission.session_id, True, True))
        if stage == until:
            break
    return mission


def _evidence(mission, stage, **changes):
    values = dict(task_id=mission.task_id, object_id=mission.object_id, stage=stage, kind=STAGE_KIND[stage],
                  evidence_id="event-"+stage, source_id="independent-fixture-observer", session_id=mission.session_id,
                  verified=True, independent=True)
    values.update(changes)
    return MissionEvidence(**values)


def _ready_permit(contract, goal="goal-1"):
    contract.clear(True); contract.reset(contract.generation); contract.ack(contract.generation)
    permit = contract.arm(contract.generation, 10)
    contract.new_goal(goal, permit, 10.01)
    return permit


BODY = ((-.13, -.09), (.13, -.09), (.13, .09), (-.13, .09))
FORK = ((.13, -.06), (.23, -.06), (.23, .06), (.13, .06))


def _frame_known():
    graph = FrameGraph("base", [Transform2D.yaw("base", "lidar", math.pi/2, (.3, .1))])
    point = graph.transform((1., 0.), "lidar", "base")
    return _check(math.dist(point, (.3, 1.1)) < 1e-9, transformed_point=point, scope="SE2_fixture")


def _frame_roundtrip():
    graph = FrameGraph("base", [Transform2D.yaw("base", "mount", .4, (.2, -.1)),
                                Transform2D.yaw("mount", "camera", -.7, (.1, .05))])
    original = (.62, -.41)
    actual = graph.transform(graph.transform(original, "camera", "base"), "base", "camera")
    return _check(math.dist(original, actual) < 1e-9, roundtrip_error_m=math.dist(original, actual))


def _frame_bad_rotation():
    first = _expect_rejection(lambda: Transform2D("base", "child", ((-1., 0.), (0., 1.))).validate())
    second = _expect_rejection(lambda: Transform2D("base", "child", ((1., 1.), (0., 1.))).validate())
    return {"reflection": first, "nonorthonormal": second}


def _frame_bad_units():
    return {"millimetres": _expect_rejection(lambda: Transform2D("base","child",length_unit="mm").validate()),
            "degrees": _expect_rejection(lambda: Transform2D("base","child",angle_unit="deg").validate())}


def _frame_nonfinite():
    return {"transform": _expect_rejection(lambda:Transform2D("base","a",translation=(float("nan"),0)).validate()),
            "identity_point": _expect_rejection(lambda:FrameGraph("base",[]).transform((float("inf"),0),"base","base"))}


def _envelope_fork():
    body = conservative_envelope([BODY], uncertainty_m=0, margin_m=.01)
    full = conservative_envelope([BODY, FORK], uncertainty_m=0, margin_m=.01)
    return _check(full.contains(body) and full.xmax > body.xmax, body_front_m=body.xmax, fork_front_m=full.xmax)


def _envelope_uncertainty():
    first = conservative_envelope([BODY, FORK], uncertainty_m=.01, margin_m=.01)
    second = conservative_envelope([BODY, FORK], uncertainty_m=.04, margin_m=.01)
    return _check(second.contains(first), original_bounds=first.__dict__, enlarged_bounds=second.__dict__)


def _rotation_bound():
    envelope = conservative_envelope([BODY, FORK], uncertainty_m=.02, margin_m=.01)
    bound = rotation_sweep_bound(envelope)
    farthest = max(math.hypot(x, y) for x,y in envelope.corners())
    return _check(bound["radius_m"] >= farthest and bound["radius_m"] > .23, **bound)


def _shrink(moving, verified):
    old = Envelope2D(-.2,-.2,.3,.2,"old")
    new = Envelope2D(-.1,-.1,.2,.1,"new")
    result = accept_envelope_update(old,new,moving=moving,independent_measurement_verified=verified)
    return _check(result["accepted"] == (not moving and verified), **result)


def _stop_known():
    result = stopping_distance_model(.2,.3,.4,.02,bounds_verified=True)
    return _check(abs(result["distance_m"]-.13)<1e-9 and not result["physical_validation"], **result)


def _stop_unknown():
    results = [stopping_distance_model(.2,.3,None,.02), stopping_distance_model(.2,.3,0,.02,bounds_verified=True),
               stopping_distance_model(float("nan"),.3,.4,.02,bounds_verified=True)]
    return _check(all(r["status"] == "UNKNOWN" and r["distance_m"] is None for r in results), results=results)


def _lift_good(**changes):
    values = dict(reference_verified=True,reference_id="home",limit_evidence_id="limit-event",reference_session="s1",
                  current_session="s1",lower_limit=False,upper_limit=False,position_interval_m=(.05,.06))
    values.update(changes)
    return lift_evidence_status(**values)


def _lift_unknown():
    result = _lift_good(reference_verified=False)
    return _check(result["status"] == "UNKNOWN" and result["position_interval_m"] is None, **result)


def _lift_dual():
    result = _lift_good(lower_limit=True,upper_limit=True)
    return _check(result["status"] == "CONFLICT" and len(result["blocked_directions"])==2, **result)


def _lift_obsolete():
    results = [_lift_good(reference_session="old_boot"),_lift_good(manual_position_changed=True)]
    return _check(all(r["status"] == "UNKNOWN" for r in results), results=results)


def _lift_limit():
    result = _lift_good(upper_limit=True)
    return _check(result["blocked_directions"] == ["up"] and not result["actual_motion_permission"], **result)


def _mission_complete():
    mission = _mission()
    return _check(mission.stage=="COMPLETE" and len(mission.events)==len(STAGES),
                  stages=[e["stage"] for e in mission.events], physical_completion_verified=False)


def _mission_ack():
    mission = _mission("LIFT")
    return _expect_rejection(lambda: mission.advance(_evidence(mission,"VERIFY_LOAD",command_ack_only=True)))


def _mission_independent():
    mission = _mission("LIFT")
    return _expect_rejection(lambda: mission.advance(_evidence(mission,"VERIFY_LOAD",independent=False)))


def _mission_withdraw():
    mission = _mission("LOWER")
    denied = _expect_rejection(lambda: mission.advance(_evidence(mission,"WITHDRAW")))
    mission.advance(_evidence(mission,"VERIFY_SUPPORT")); mission.advance(_evidence(mission,"WITHDRAW"))
    return _check(mission.stage=="WITHDRAW", before_support=denied, after_support="WITHDRAW", final_release_not_yet_verified=True)


def _mission_wrong_id():
    mission = _mission("APPROACH")
    wrong = _expect_rejection(lambda: mission.advance(_evidence(mission,"ALIGN",object_id="other-box")))
    reused = _expect_rejection(lambda: mission.advance(_evidence(mission,"ALIGN",evidence_id="event-APPROACH")))
    return {"wrong_object":wrong,"reused_event":reused}


def _ledger_duplicate():
    ledger = EvidenceLedger()
    try:
        first=ledger.request("task","box","slot"); second=ledger.request("task","box","slot")
        return _check(first["created"] and not second["created"] and not second["physical_complete"], first=first,duplicate=second)
    finally: ledger.close()


def _ledger_conflict():
    ledger = EvidenceLedger()
    try:
        ledger.request("task","box","slot")
        return _expect_rejection(lambda: ledger.request("task","other-box","slot"))
    finally: ledger.close()


def _ledger_not_complete():
    ledger = EvidenceLedger(); mission=_mission("LIFT")
    try:
        ledger.request(mission.task_id,mission.object_id,"slot")
        return _expect_rejection(lambda: ledger.commit_synthetic_completion(mission))
    finally: ledger.close()


def _ledger_rewards():
    ledger=EvidenceLedger();mission=_mission()
    try:
        ledger.request(mission.task_id,mission.object_id,"slot")
        a=ledger.award_stage(mission,"VERIFY_LOAD");b=ledger.award_stage(mission,"VERIFY_LOAD")
        direct_completion=_expect_rejection(lambda:ledger.award_stage(mission,"COMPLETE"))
        c=ledger.commit_synthetic_completion(mission);d=ledger.commit_synthetic_completion(mission)
        return _check(a==1 and b==0 and c["task_bonus"]==10 and d["task_bonus"]==0 and not c["physical_complete"],
                      first_stage_reward=a,duplicate_stage_reward=b,first_completion=c,duplicate_completion=d,
                      direct_completion_reward_rejected=direct_completion)
    finally: ledger.close()


def _diagnosis_unknown():
    result=diagnose_motion(symptom="rotation_failed",observed_motion_m=0)
    return _check(len(result["hypotheses"])>=3 and not result["root_cause_confirmed"] and not result["pwm_increase_recommended"],**result)


def _diagnosis_voltage():
    unmeasured=diagnose_motion(symptom="stalled",voltage_v=4.5,voltage_min_v=6,voltage_measurement_verified=False)
    measured=diagnose_motion(symptom="stalled",voltage_v=4.5,voltage_min_v=6,voltage_measurement_verified=True)
    return _check(unmeasured["hypotheses"][0]["status"]=="UNRESOLVED" and measured["hypotheses"][0]["name"]=="low_voltage_observed"
                  and not measured["root_cause_confirmed"],unverified=unmeasured,verified_measurement=measured)


def _diagnosis_stop():
    result=diagnose_motion(symptom="stopped",stop_reason="input_deadline_expired")
    return _check(result["classification"]=="recorded_protective_stop" and not result["automatic_patch_applied"],**result)


def _permit_chain():
    contract=OfflinePermitContract();permit=_ready_permit(contract)
    result=contract.check_intent(permit,1,10.02)
    return _check(result["synthetic_contract_accepted"] and not result["actual_motion_permission"],**result)


def _permit_stale():
    contract=OfflinePermitContract();permit=_ready_permit(contract);contract.stop()
    return _expect_rejection(lambda: contract.check_intent(permit,2,10.02))


def _permit_health():
    contract=OfflinePermitContract();permit=_ready_permit(contract);health=contract.refresh_health()
    rejected=_expect_rejection(lambda:contract.check_intent(permit,1,10.31))
    return _check(health["permit_expiry_unchanged"]==permit.expires_at_s,health=health,expired_request=rejected)


def _permit_order():
    contract=OfflinePermitContract()
    early=_expect_rejection(lambda:contract.arm(contract.generation,10))
    contract.clear(True);unchanged=contract.state;contract.reset(contract.generation);contract.ack(contract.generation)
    permit=contract.arm(contract.generation,10)
    no_goal=_expect_rejection(lambda:contract.check_intent(permit,1,10.01))
    return _check(unchanged=="STOPPED",arm_before_ack=early,clear_only_state=unchanged,no_new_goal=no_goal)


def _permit_replays():
    contract=OfflinePermitContract();permit=_ready_permit(contract)
    contract.check_intent(permit,1,10.02)
    duplicate=_expect_rejection(lambda:contract.check_intent(permit,1,10.03))
    contract.stop();contract.clear(True);contract.reset(contract.generation);contract.ack(contract.generation)
    newer=contract.arm(contract.generation,11)
    old_goal=_expect_rejection(lambda:contract.new_goal("goal-1",newer,11.01))
    return {"duplicate_sequence":duplicate,"old_goal_replay":old_goal}


# IDs are stable report identifiers. Requirement tags describe only the
# software contract being checked, never blanket completion of that requirement.
CASES = [
    ("D01","Known planar transform",["A06","F05","F14","T06"],_frame_known),
    ("D02","Reject implicit mm/degree units",["A06","F14","F35","T06"],_frame_bad_units),
    ("D03","Reject reflection and nonorthogonal rotation",["A06","F05","T06"],_frame_bad_rotation),
    ("D04","Reject cyclic frames",["A06","F14","T06"],lambda:_expect_rejection(lambda:FrameGraph("base",[Transform2D("a","b"),Transform2D("b","a")]))),
    ("D05","Reject duplicate parent",["A06","T06"],lambda:_expect_rejection(lambda:FrameGraph("base",[Transform2D("base","a"),Transform2D("other","a")]))),
    ("D06","Reject missing parent frame",["A06","F14","T06"],lambda:_expect_rejection(lambda:FrameGraph("base",[Transform2D("missing","a")]))),
    ("D07","Nested transform round trip",["A06","T06"],_frame_roundtrip),
    ("D08","Reject nonfinite transform",["A06","F35","T06"],_frame_nonfinite),
    ("D09","Fork protrusion enlarges envelope",["A07","F17","F21","S05","T07"],_envelope_fork),
    ("D10","Uncertainty cannot shrink bounds",["A07","S07","T07"],_envelope_uncertainty),
    ("D11","Full-rotation conservative bound",["A07","F16","F17","T07"],_rotation_bound),
    ("D12","Moving envelope shrink rejected",["A07","A09","T07"],lambda:_shrink(True,True)),
    ("D13","Unverified stopped shrink rejected",["A07","A09","T07"],lambda:_shrink(False,False)),
    ("D14","Verified stopped new-version shrink contract",["A07","A09","T07"],lambda:_shrink(False,True)),
    ("D15","Stopping formula under supplied bounds",["A07","F06","S03","T07"],_stop_known),
    ("D16","Missing/invalid braking bounds remain unknown",["A07","F06","S03","T07"],_stop_unknown),
    ("D17","Saved lift height without reference unknown",["A08","F27","S10","T08"],_lift_unknown),
    ("D18","Both lift limits active conflict",["A08","F28","S10","T08"],_lift_dual),
    ("D19","Reboot/manual movement invalidates reference",["A08","F27","S10","T08"],_lift_obsolete),
    ("D20","Upper limit blocks upward direction evidence",["A08","F22","F28","S10","T08"],_lift_limit),
    ("D21","Full mission evidence sequence",["A03","F23","F25","T03","G6"],_mission_complete),
    ("D22","Lift command ACK is not load evidence",["A03","F23","T03"],_mission_ack),
    ("D23","Load verification requires independent evidence",["A03","F23","S05","T03"],_mission_independent),
    ("D24","Support before withdrawal before final release",["A03","F25","F26","T03"],_mission_withdraw),
    ("D25","Reject wrong object and recycled evidence",["A03","F19","F33","T03"],_mission_wrong_id),
    ("D26","SQLite duplicate task ID is idempotent",["A03","F19","F32","T03"],_ledger_duplicate),
    ("D27","Conflicting duplicate task payload rejected",["A03","F19","F32","T03"],_ledger_conflict),
    ("D28","Request/lift ACK cannot complete DB task",["A03","F23","F32","F33","T03"],_ledger_not_complete),
    ("D29","Stage/task rewards and completion idempotent",["A05","F32","F33","T05"],_ledger_rewards),
    ("D30","No-motion retains multiple hypotheses",["A02","F01","F04","F08","T02"],_diagnosis_unknown),
    ("D31","Low voltage measurement is not root-cause proof",["A02","F09","S01","T02"],_diagnosis_voltage),
    ("D32","Protective stop is not automatically motor fault",["A02","F02","F29","T02"],_diagnosis_stop),
    ("D33","Explicit lifecycle and new-goal contract",["A09","F29","T09","G4"],_permit_chain),
    ("D34","STOP invalidates old permit",["A09","F29","T09"],_permit_stale),
    ("D35","Health update cannot extend permit",["A09","F29","T09"],_permit_health),
    ("D36","No automatic ARM/reused goal or sequence",["A09","F29","T09"],lambda:{"ordering":_permit_order(),"replays":_permit_replays()}),
]

NOT_EVALUATED = [
    ("D37","Real geometry/3D collision/floor support",["A07","F17","F24","F37","S04","S05","G2","G3"],
     "SE2 synthetic bounds do not measure hardware, mass, tipping, overhang height, holes or floor support."),
    ("D38","Physical lift travel/load/holding behavior",["A08","F22","F24","F28","F36","S05","S10","G3","G6"],
     "No homing, lift travel, limit wiring, force, load or power-loss holding experiment was performed."),
    ("D39","Real power/slip/braking and causal diagnosis",["A02","F01","F03","F04","F06","F08","F09","S01","S02","S03","G3"],
     "Formula and diagnosis evidence contracts are not motor/system identification or fault-cause confirmation."),
    ("D40","Physical output protection and autonomous operation",["A09","F18","F30","F31","F36","G5","G6","G8","G9"],
     "Offline permit tests do not exercise GPIO ownership, hardware stop, watchdog timing, people or real autonomy."),
]


def run_domain_checks():
    results = []
    for case_id,title,requirements,operation in CASES:
        try:
            evidence=operation()
            passed,status=True,"PASS"
        except Exception as exc:
            passed,status=False,"FAIL"
            evidence={"error_type":type(exc).__name__,"error":str(exc)}
        results.append({"id":case_id,"title":title,"passed":passed,"status":status,
                        "requirement_ids":requirements,"coverage_level":"synthetic_contract",
                        "evidence":{"scope":"offline_fixture_only","hardware_accessed":False,
                                    "actual_motion_permission":False,"details":evidence},"source_ids":[]})
    for case_id,title,requirements,reason in NOT_EVALUATED:
        results.append({"id":case_id,"title":title,"passed":None,"status":"NOT_EVALUATED",
                        "requirement_ids":requirements,"coverage_level":"not_evaluated",
                        "evidence":{"reason":reason,"hardware_accessed":False,"actual_motion_permission":False},"source_ids":[]})
    return results
