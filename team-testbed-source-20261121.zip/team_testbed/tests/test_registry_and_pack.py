import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import subprocess
import sys

from team_testbed.registry import (DATA, CORE_IDS, MANUAL_IDS, NOTION_IDS, GIT_IDS,
                                   REQUIRED_BY_FILE, load_registry, trace_requirements)
from team_testbed.source_pack import import_source_pack, SOURCE_SPECS
from team_testbed.runner import summarize_unittest, snapshot_preserved_sources, source_preservation_case
from team_testbed import runner


def example(**changes):
    return dict({'id': 'x', 'status': 'PASS', 'passed': True, 'requirement_ids': ['A01']}, **changes)


def coverage_row(rows, ident):
    return next(row for row in rows if row['id'] == ident)


class TraceabilityTests(unittest.TestCase):
    def test_all_published_requirement_families_retained(self):
        registry = load_registry()
        ids = {x['id'] for x in registry['requirements']}
        required = {f'{p}{i:02}' for p, n in [('A', 10), ('F', 37), ('S', 10), ('T', 10)] for i in range(1, n+1)}
        required |= {f'G{i}' for i in range(10)}
        self.assertTrue(required <= ids)
        self.assertEqual((len(CORE_IDS), len(MANUAL_IDS), len(NOTION_IDS), len(GIT_IDS)), (77, 14, 19, 8))
        self.assertEqual(len(ids), 118)
        self.assertEqual(set(registry['registry_file_sha256']), set(REQUIRED_BY_FILE))
        self.assertEqual(len(registry['documents']), 3)
        for document in registry['documents']:
            self.assertGreater(len(document['text']), 5000)

    def test_passing_example_is_not_full_acceptance(self):
        row = coverage_row(trace_requirements(load_registry(), [example()]), 'A01')
        self.assertEqual(row['coverage_status'], 'PARTIAL_OFFLINE_EVIDENCE')
        self.assertFalse(row['full_acceptance_verified'])
        self.assertEqual(row['physical_acceptance'], 'NOT_EVALUATED')

    def test_unknown_requirement_and_duplicate_case_fail(self):
        with self.assertRaises(ValueError):
            trace_requirements(load_registry(), [example(requirement_ids=['typo'])])
        with self.assertRaises(ValueError):
            trace_requirements(load_registry(), [example()] * 2)

    def test_missing_requirement_remains_visible(self):
        row = coverage_row(trace_requirements(load_registry(), []), 'G9')
        self.assertEqual(row['coverage_status'], 'NOT_EVALUATED')
        self.assertEqual(row['case_ids'], [])

    def test_deleted_requirement_in_each_family_is_rejected(self):
        for ident in ('A01', 'F07', 'G9', 'S10', 'T10', 'MANUAL-L03',
                      'TEAM-NOTION-ARUCO', 'TEAM-CAMERA-LIDAR-INTEGRATION'):
            with self.subTest(ident=ident):
                registry = load_registry()
                registry['requirements'] = [r for r in registry['requirements'] if r['id'] != ident]
                with self.assertRaisesRegex(ValueError, 'Missing mandatory'):
                    trace_requirements(registry, [])

    def test_missing_registry_file_and_deleted_source_row_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            destination = Path(tmp)
            for name in REQUIRED_BY_FILE:
                (destination / name).write_bytes((DATA / name).read_bytes())
            missing = destination / 'notion_requirements.json'
            raw = missing.read_bytes()
            missing.unlink()
            with self.assertRaisesRegex(ValueError, 'Missing mandatory registry file'):
                load_registry(destination)
            document = json.loads(raw)
            document['requirements'].pop()
            missing.write_text(json.dumps(document), encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'Missing mandatory requirements'):
                load_registry(destination)

    def test_status_and_passed_must_agree(self):
        for status, passed in [('PASS', False), ('PASS', 1), ('FAIL', True), ('FAIL', 0),
                               ('NOT_EVALUATED', True), ('CONTRACT_CONFLICT', True)]:
            with self.subTest(status=status, passed=passed), self.assertRaises(ValueError):
                trace_requirements(load_registry(), [example(status=status, passed=passed)])
        for status in ('NOT_EVALUATED', 'CONTRACT_CONFLICT'):
            for passed in (None, False):
                with self.subTest(status=status, passed=passed):
                    rows = trace_requirements(load_registry(), [example(status=status, passed=passed)])
                    self.assertNotEqual(coverage_row(rows, 'A01')['coverage_status'], 'PARTIAL_OFFLINE_EVIDENCE')

    def test_case_requires_explicit_mapping_and_boolean_verdict(self):
        for tags in (None, [], ['A01', 'A01'], [4], 'A01'):
            with self.subTest(tags=tags), self.assertRaises(ValueError):
                trace_requirements(load_registry(), [example(requirement_ids=tags)])
        row = example(); del row['passed']
        with self.assertRaises(ValueError):
            trace_requirements(load_registry(), [row])

    def test_registry_malformed_rows_are_rejected(self):
        for row in (None, {'id': []}, {'id': 'X', 'title': 4}):
            registry = load_registry()
            registry['requirements'].append(row)
            with self.subTest(row=row), self.assertRaises(ValueError):
                trace_requirements(registry, [])

    def test_unreviewed_private_pack_is_rejected_before_writing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            value = {'schema_version': 1, 'hardware_execution': False,
                     'files': [{'filename': '../escape.py', 'text': 'print(1)', 'sha256': 'x'}]*2}
            pack = root / 'pack.json'
            pack.write_text(json.dumps(value), encoding='utf-8')
            with self.assertRaises(ValueError):
                import_source_pack(pack, root / 'sources')
            self.assertFalse((root / 'sources').exists())

    def test_duplicate_json_keys_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            pack = Path(tmp) / 'pack.json'
            pack.write_text('{"schema_version":1,"schema_version":1}', encoding='utf-8')
            with self.assertRaises(ValueError):
                import_source_pack(pack, Path(tmp) / 'sources')


class RegressionAccountingTests(unittest.TestCase):
    def test_empty_and_all_skipped_are_not_evaluated(self):
        for log, run, skipped in [('Ran 0 tests in 0.000s\n\nOK\n', 0, 0),
                                  ('Ran 3 tests in 0.001s\n\nOK (skipped=3)\n', 3, 3)]:
            row = summarize_unittest(log, 0)
            self.assertEqual(row['status'], 'NOT_EVALUATED')
            self.assertIsNone(row['passed'])
            self.assertEqual((row['tests_run'], row['tests_skipped'], row['tests_executed']), (run, skipped, 0))

    def test_partial_skips_count_only_executed_test_bodies(self):
        row = summarize_unittest('Ran 4 tests in 0.100s\n\nOK (skipped=1)\n', 0)
        self.assertEqual(row['status'], 'PASS')
        self.assertEqual(row['tests_executed'], 3)

    def test_failed_or_missing_summary_cannot_pass(self):
        for log, code in [('Ran 2 tests in 0.1s\n\nFAILED (failures=1)\n', 1),
                           ('anything\n', 0), ('Ran 1 test in 0.1s\n\nOK (skipped=2)\n', 0)]:
            with self.subTest(log=log):
                self.assertEqual(summarize_unittest(log, code)['status'], 'FAIL')

    def test_actual_empty_and_all_skipped_discovery_never_passes(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(runner, 'ROOT', Path(tmp)):
            root = Path(tmp)
            test_dir = root / 'manual_station' / 'tests'
            test_dir.mkdir(parents=True)
            first = runner.run_regressions(root)
            self.assertEqual(first[0]['status'], 'NOT_EVALUATED')
            self.assertEqual(first[0]['evidence']['tests_run'], 0)
            (test_dir / 'test_skipped.py').write_text(
                "import unittest\n@unittest.skip('fixture skip')\nclass X(unittest.TestCase):\n"
                "    def test_body(self):\n        raise RuntimeError('must not run')\n", encoding='utf-8')
            second = runner.run_regressions(root)
            self.assertEqual(second[0]['status'], 'NOT_EVALUATED')
            self.assertEqual(second[0]['evidence']['tests_skipped'], 1)
            self.assertEqual(second[0]['evidence']['tests_executed'], 0)

    def test_optimized_cli_refuses_before_output_creation(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / 'should_not_exist'
            result = subprocess.run([sys.executable, '-O', '-m', 'team_testbed', '--suite', 'contracts',
                                     '--output', str(output)], cwd=runner.ROOT, capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('requires assertions', result.stderr)
            self.assertFalse(output.exists())


class PreservationTests(unittest.TestCase):
    def create_required(self, root):
        for name in runner.REQUIRED_FROZEN:
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('# frozen fixture\n', encoding='utf-8')

    def test_all_missing_sources_cannot_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            snapshot = snapshot_preserved_sources(tmp)
            row = source_preservation_case(snapshot, snapshot)
            self.assertEqual(row['status'], 'NOT_EVALUATED')
            self.assertEqual(len(row['evidence']['before']['missing_required']), 3)

    def test_required_sources_pass_with_optional_manual_explicitly_absent(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); self.create_required(root)
            snapshot = snapshot_preserved_sources(root)
            row = source_preservation_case(snapshot, snapshot)
            self.assertEqual(row['status'], 'PASS')
            self.assertFalse(row['evidence']['before']['optional_manual']['directory_present'])

    def test_changed_added_and_deleted_sources_fail(self):
        for change in ('changed', 'added', 'removed'):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); self.create_required(root)
                manual = root / 'manual_station'; manual.mkdir()
                (manual / 'original.py').write_text('# original\n', encoding='utf-8')
                before = snapshot_preserved_sources(root)
                if change == 'changed':
                    (root / runner.REQUIRED_FROZEN[0]).write_text('# changed\n', encoding='utf-8')
                elif change == 'added':
                    (manual / 'new.py').write_text('# new\n', encoding='utf-8')
                else:
                    (manual / 'original.py').unlink()
                row = source_preservation_case(before, snapshot_preserved_sources(root))
                self.assertEqual(row['status'], 'FAIL')
                self.assertEqual(len(row['evidence'][change]), 1)

    def test_single_missing_required_source_is_visible(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); self.create_required(root)
            (root / runner.REQUIRED_FROZEN[1]).unlink()
            snapshot = snapshot_preserved_sources(root)
            self.assertEqual(source_preservation_case(snapshot, snapshot)['status'], 'NOT_EVALUATED')


class SourcePackSchemaTests(unittest.TestCase):
    def valid_fixture_pack(self):
        texts = ['raise RuntimeError("not executed")\n', '# second fixture\n']
        specs = {str(i): {'filename': f'fixture_{i}.py', 'sha256': hashlib.sha256(text.encode()).hexdigest()}
                 for i, text in enumerate(texts)}
        value = {'schema_version': 1, 'hardware_execution': False,
                 'files': [{**specs[str(i)], 'text': text} for i, text in enumerate(texts)]}
        return specs, value

    def test_valid_pinned_pack_is_written_without_execution_and_is_repeatable(self):
        specs, value = self.valid_fixture_pack()
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(SOURCE_SPECS, specs, clear=True):
            root = Path(tmp); pack = root / 'pack.json'; destination = root / 'sources'
            pack.write_text(json.dumps(value), encoding='utf-8')
            self.assertEqual(import_source_pack(pack, destination), destination)
            self.assertEqual(import_source_pack(pack, destination), destination)
            self.assertEqual(len(list(destination.glob('*.py'))), 2)
            self.assertEqual((destination / 'fixture_0.py').read_text(), value['files'][0]['text'])

    def test_malformed_json_types_fail_before_destination_exists(self):
        specs, valid = self.valid_fixture_pack()
        invalid = [[], None, 1, {**valid, 'schema_version': True}, {**valid, 'hardware_execution': 0},
                   {**valid, 'files': {}}, {**valid, 'files': [None, None]},
                   {**valid, 'files': [{'filename': [], 'text': 'x', 'sha256': 'x'}] * 2},
                   {**valid, 'files': [{'filename': 'fixture_0.py', 'text': [], 'sha256': 'x'}] * 2}]
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(SOURCE_SPECS, specs, clear=True):
            root = Path(tmp); pack = root / 'pack.json'; destination = root / 'sources'
            for value in invalid:
                with self.subTest(value=value):
                    pack.write_text(json.dumps(value), encoding='utf-8')
                    with self.assertRaises(ValueError):
                        import_source_pack(pack, destination)
                    self.assertFalse(destination.exists())

    def test_tampered_second_source_prevents_all_writes(self):
        specs, value = self.valid_fixture_pack()
        value['files'][1]['text'] = '# changed\n'
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(SOURCE_SPECS, specs, clear=True):
            root = Path(tmp); pack = root / 'pack.json'
            pack.write_text(json.dumps(value), encoding='utf-8')
            with self.assertRaises(ValueError):
                import_source_pack(pack, root / 'sources')
            self.assertFalse((root / 'sources').exists())

    def test_existing_different_source_is_preserved(self):
        specs, value = self.valid_fixture_pack()
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(SOURCE_SPECS, specs, clear=True):
            root = Path(tmp); pack = root / 'pack.json'; destination = root / 'sources'; destination.mkdir()
            existing = destination / 'fixture_1.py'; existing.write_text('# owner version\n', encoding='utf-8')
            pack.write_text(json.dumps(value), encoding='utf-8')
            with self.assertRaises(ValueError):
                import_source_pack(pack, destination)
            self.assertEqual(existing.read_text(), '# owner version\n')
            self.assertFalse((destination / 'fixture_0.py').exists())

    def test_nonfinite_and_oversized_packs_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            pack = Path(tmp) / 'pack.json'
            for raw in ('{"schema_version":NaN}', ' ' * (200 * 1024 + 1)):
                with self.subTest(size=len(raw)):
                    pack.write_text(raw, encoding='utf-8')
                    with self.assertRaises(ValueError):
                        import_source_pack(pack, Path(tmp) / 'sources')
                    self.assertFalse((Path(tmp) / 'sources').exists())


if __name__ == '__main__':
    unittest.main()
