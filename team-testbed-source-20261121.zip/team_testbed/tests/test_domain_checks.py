"""Behavioral fixtures for the offline domain contracts; no hardware tests."""
import json
import unittest

from team_testbed.domain_checks import CASES, NOT_EVALUATED, run_domain_checks


class DomainContractTests(unittest.TestCase):
    pass


def fixture_test(case_id, operation):
    def test(self):
        evidence=operation()
        self.assertIsInstance(evidence,dict)
        json.dumps(evidence,allow_nan=False)
    test.__name__="test_"+case_id
    return test


for case_id,title,requirements,operation in CASES:
    setattr(DomainContractTests,"test_"+case_id+"_"+title.lower().replace(" ","_").replace("/","_"),fixture_test(case_id,operation))


class DomainCoverageBoundaryTests(unittest.TestCase):
    def test_report_ids_and_coverage_are_explicit(self):
        report=run_domain_checks()
        self.assertEqual(len(report),40)
        self.assertEqual(len({row["id"] for row in report}),40)
        self.assertTrue(all(row["status"]=="PASS" for row in report[:36]))
        self.assertTrue(all(row["requirement_ids"] for row in report))
        json.dumps(report,allow_nan=False)

    def test_unperformed_physical_checks_never_become_passes(self):
        report=run_domain_checks()
        pending=[row for row in report if row["status"]=="NOT_EVALUATED"]
        self.assertEqual(len(pending),4)
        self.assertTrue(all(row["passed"] is None for row in pending))
        self.assertTrue(all(not row["evidence"]["actual_motion_permission"] for row in report))
        self.assertTrue(all(not row["evidence"]["hardware_accessed"] for row in report))


if __name__=="__main__":
    unittest.main()
