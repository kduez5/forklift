import unittest
from unittest.mock import patch

from team_testbed import team_adapters as adapter


class OriginalTeamSourceTests(unittest.TestCase):
    def test_reviewed_definitions_run_with_fake_io(self):
        results=adapter.run_team_checks()
        self.assertFalse([r for r in results if r['status']=='FAIL'],results)
        self.assertEqual(sum(r['status']=='PASS' for r in results),9)
        self.assertEqual({r['id'] for r in results if r['status']=='CONTRACT_CONFLICT'},
                         {'TEAM10','TEAM11','TEAM12'})
        self.assertEqual(sum(r['status']=='NOT_EVALUATED' for r in results),1)
        self.assertTrue(all(r['hardware_accessed'] is False and r['hardware_verified'] is False for r in results))

    def test_snapshot_hash_guard_rejects_modified_bytes(self):
        original=adapter.Path.read_bytes
        def corrupted(path):
            result=original(path)
            return result+b'\n# altered' if path.name=='github_forward_wheels.py.txt' else result
        with patch.object(adapter.Path,'read_bytes',corrupted):
            with self.assertRaisesRegex(ValueError,'hash differs'):
                adapter._wheels()

    def test_loader_does_not_allow_unreviewed_imports_or_main(self):
        selected=adapter._wheels()
        self.assertNotIn('main',selected)
        self.assertNotIn('open_rp1',selected)
        self.assertNotIn('__import__',selected['__builtins__'])
        self.assertNotIn('open',selected['__builtins__'])
        self.assertNotIn('gpiozero',selected)
        self.assertNotIn('lgpio',selected)
        with self.assertRaisesRegex(ValueError,'outside the reviewed'):
            adapter._load('GH-WHEELS',('main',))

    def test_result_schema_has_source_and_requirement_traceability(self):
        results=adapter.run_team_checks()
        known={s['id'] for s in adapter.source_manifest()['sources']}
        requirements=adapter.json.loads((adapter.BASE/'data/git_requirements.json').read_text(encoding='utf-8'))
        known_requirements={r['id'] for r in requirements['requirements']}
        self.assertEqual(len({r['id'] for r in results}),len(results))
        for row in results:
            self.assertTrue(row['requirement_ids'])
            self.assertTrue(set(row['source_ids'])<=known)
            self.assertIn(row['coverage_level'],('original_logic_stubbed_io','static_source_contract'))
            self.assertTrue(row['evidence'])
            self.assertTrue({r for r in row['requirement_ids'] if r.startswith('TEAM-')} <= known_requirements)


if __name__=='__main__':
    unittest.main()
