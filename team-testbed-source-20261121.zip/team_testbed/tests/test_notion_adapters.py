import json
from pathlib import Path
import tempfile
import unittest

from team_testbed.notion_adapters import DEFAULT_SOURCE_ROOT, SOURCE_SPECS, run_notion_checks


class NotionAdapterTests(unittest.TestCase):
    def test_original_sources_have_eight_passes_and_two_visible_conflicts(self):
        if not all((DEFAULT_SOURCE_ROOT / s['filename']).is_file() for s in SOURCE_SPECS.values()):
            self.skipTest('Private Notion source pack is not installed; check reports NOT_EVALUATED')
        rows = run_notion_checks()
        self.assertEqual(len(rows), 10)
        self.assertEqual([r['id'] for r in rows if r['status'] == 'PASS'],
                         ['N01', 'N02', 'N03', 'N06', 'N07', 'N08', 'N09', 'N10'])
        self.assertEqual([r['id'] for r in rows if r['status'] == 'CONTRACT_CONFLICT'], ['N04', 'N05'])
        for row in rows:
            self.assertFalse(row['evidence']['actual_motion_permission'])
            self.assertEqual(row['evidence']['physical_actuation_count'], 0)
            self.assertEqual(row['passed'], row['status'] == 'PASS')
        json.dumps(rows, allow_nan=False)

    def test_missing_sources_are_not_evaluated(self):
        with tempfile.TemporaryDirectory() as tmp:
            rows = run_notion_checks(Path(tmp))
        self.assertTrue(all(r['status'] == 'NOT_EVALUATED' and not r['passed'] for r in rows))

    def test_changed_source_is_never_executed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            marker = root / 'must_not_exist.txt'
            for spec in SOURCE_SPECS.values():
                (root / spec['filename']).write_text(
                    'from pathlib import Path\nPath(' + repr(str(marker)) + ').write_text("executed")\n', encoding='utf-8')
            rows = run_notion_checks(root)
            self.assertFalse(marker.exists())
            self.assertTrue(all(r['status'] == 'NOT_EVALUATED' for r in rows))
            self.assertTrue(all('SHA256' in r['evidence']['not_evaluated_reason'] for r in rows))

    def test_repeated_synthetic_runs_do_not_retain_state(self):
        self.assertEqual(run_notion_checks(), run_notion_checks())


if __name__ == '__main__':
    unittest.main()
