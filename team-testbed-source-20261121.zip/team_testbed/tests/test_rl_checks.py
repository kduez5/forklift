import copy
import unittest

from team_testbed.rl_checks import validate_split, paired_comparison, nondegradation, summarize_trials, wilson95


def metrics(success=True,steps=20):
    rows=[{'seed':5000000+i,'success':success,'steps':steps,'distance_error_m':.06,
           'heading_error_rad':.1,'blocked':0,'physical_collisions':0} for i in range(80)]
    return {'episodes_detail':rows,'episodes':80,'successes':80 if success else 0,'success_rate':int(success),
            'mean_steps':steps,'mean_return':1.,'mean_blocked':0,'physical_collisions':0,
            'q_sha256_before':'same','q_sha256_after':'same','evaluation_learning_disabled':True}


class RLStudyTests(unittest.TestCase):
    def test_environment_split_and_rng_seed_are_distinct_concepts(self):
        self.assertTrue(validate_split([0,999999],[5000000,5000001]))
        for train,evaluation in [([1000000],[5000000]),([1],[1]),([],[5000000,5000000]),([],[True])]:
            with self.assertRaises(ValueError): validate_split(train,evaluation)

    def test_pairing_requires_same_environments_and_catches_regression(self):
        learned,baseline=metrics(),metrics()
        learned['episodes_detail'][9]['success']=False
        pair=paired_comparison(learned,baseline)
        self.assertEqual(pair['learned_fails_comparator_succeeds'],[5000009])
        self.assertFalse(nondegradation(learned,baseline)['passed'])
        learned['episodes_detail'][9]['seed']=9
        with self.assertRaises(ValueError): paired_comparison(learned,baseline)

    def test_nondegradation_catches_constraints_and_terminal_precision(self):
        learned,baseline=metrics(),metrics()
        self.assertTrue(nondegradation(learned,baseline)['passed'])
        learned['mean_blocked']=.01
        self.assertFalse(nondegradation(learned,baseline)['passed'])
        learned=metrics(); learned['episodes_detail'][3]['distance_error_m']=.091
        self.assertFalse(nondegradation(learned,baseline)['passed'])

    def test_aggregation_keeps_shared_environment_count_and_adoption_separate(self):
        trials=[]
        for seed in (1,2,3):
            trial={'settings':{'seed':seed},'evaluation_seeds':list(range(5000000,5000080))}
            trial.update({name:metrics(name!='untrained',21 if name=='learned' else 20) for name in ('learned','baseline','phase_rule','untrained')})
            trials.append(trial)
        summary=summarize_trials(trials)
        self.assertEqual(summary['unique_evaluation_environments'],80)
        self.assertEqual(summary['learned_policy_evaluation_episodes'],240)
        self.assertTrue(summary['all_sampled_nondegradation_gates_passed'])
        self.assertFalse(summary['candidate_adoption_gate_passed'])
        mutated=copy.deepcopy(trials); mutated[0]['learned']['q_sha256_after']='changed'
        with self.assertRaises(ValueError): summarize_trials(mutated)
        mutated=copy.deepcopy(trials); mutated[2]['evaluation_seeds'][0]=6000000
        with self.assertRaises(ValueError): summarize_trials(mutated)

    def test_success_interval_does_not_claim_certainty(self):
        low,high=wilson95(80,80)
        self.assertLess(low,1)
        self.assertAlmostEqual(high,1)
        self.assertGreater(low,.95)


if __name__=='__main__': unittest.main()
