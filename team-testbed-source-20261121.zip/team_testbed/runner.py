"""One offline command for source behavior, contract oracles and synthetic RL."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import traceback

from .registry import load_registry, sha256, trace_requirements

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_FROZEN = tuple('autonomy_lab/' + name for name in ('environment.py', 'learning.py', 'candidate.py'))


def require_assertions_enabled():
    if sys.flags.optimize:
        raise RuntimeError('Offline validation requires assertions; do not use python -O/-OO or PYTHONOPTIMIZE')


def summarize_unittest(log, returncode):
    """An empty/skipped discovery run is not evidence that tests passed."""
    counts = re.findall(r'^Ran (\d+) tests? in .+$', log, re.MULTILINE)
    endings = re.findall(r'^(OK|FAILED)(?: \(([^\n]*)\))?\s*$', log, re.MULTILINE)
    run = int(counts[-1]) if counts else None
    skipped = None
    if endings:
        match = re.search(r'(?:^|,\s*)skipped=(\d+)(?:,|$)', endings[-1][1])
        skipped = int(match.group(1)) if match else 0
    executed = run - skipped if run is not None and skipped is not None else None
    if returncode != 0:
        status, reason = 'FAIL', 'unittest process failed'
    elif run is None or skipped is None or skipped > run or endings[-1][0] != 'OK':
        status, reason = 'FAIL', 'Missing or inconsistent unittest summary'
    elif executed == 0:
        status, reason = 'NOT_EVALUATED', 'No test body executed (empty discovery or all skipped)'
    else:
        status, reason = 'PASS', 'Named offline test bodies executed successfully'
    return {'status': status, 'passed': True if status == 'PASS' else None if status == 'NOT_EVALUATED' else False,
            'tests_run': run, 'tests_skipped': skipped, 'tests_executed': executed, 'reason': reason}


def snapshot_preserved_sources(root=None):
    root = Path(root) if root is not None else ROOT
    manual = root / 'manual_station'
    optional = sorted(p for p in manual.rglob('*.py') if p.is_file()) if manual.is_dir() else []
    required = [root / name for name in REQUIRED_FROZEN]
    files = [p for p in required if p.is_file()] + optional
    return {'required_paths': list(REQUIRED_FROZEN),
            'missing_required': [name for name in REQUIRED_FROZEN if not (root / name).is_file()],
            'hashes': {p.relative_to(root).as_posix(): sha256(p) for p in files},
            'optional_manual': {'directory_present': manual.is_dir(), 'python_file_count': len(optional),
                                'scope': 'Present Python files only; absent optional manual package is not verified'}}


def source_preservation_case(before, after):
    old, new = before['hashes'], after['hashes']
    added, removed = sorted(set(new) - set(old)), sorted(set(old) - set(new))
    changed = sorted(name for name in set(old) & set(new) if old[name] != new[name])
    optional_scope_changed = before['optional_manual'] != after['optional_manual']
    if added or removed or changed or optional_scope_changed:
        status, reason = 'FAIL', 'Preserved source content or file set changed during the run'
    elif before['missing_required'] or after['missing_required']:
        status, reason = 'NOT_EVALUATED', 'Required frozen source is missing; no preservation claim is made'
    else:
        status, reason = 'PASS', 'Required frozen files and the present optional manual source set are unchanged'
    return {'id': 'SOURCE-PRESERVATION', 'title': '동결 환경·학습·존재하는 수동 원본 보존',
            'status': status, 'passed': True if status == 'PASS' else None if status == 'NOT_EVALUATED' else False,
            'requirement_ids': ['A09', 'A10', 'T09', 'T10', 'F34', 'G0'],
            'coverage_level': 'source_hash_check', 'source_ids': [],
            'evidence': {'before': before, 'after': after, 'added': added, 'removed': removed,
                         'changed': changed, 'optional_scope_changed': optional_scope_changed, 'reason': reason}}


def observation_cases():
    from integration_contracts.observations import run_fixture_validation
    result = []
    for case in run_fixture_validation()['cases']:
        num = int(case['id'][1:3])
        # These fixtures use range metadata, not camera pixels or LiDAR scans.
        tags = ['A01', 'T01', 'G1']
        tags += {
            1: ['MANUAL-S01'], 2: ['S08', 'F35'], 3: ['A10', 'T10'],
            4: ['A06', 'T06', 'F14', 'S07'],
            5: ['F11', 'S06'], 6: ['F11', 'S06'],
            7: ['A06', 'T06', 'S08'], 8: ['S08', 'F29'], 9: ['S08', 'F29'],
            10: ['S06', 'F35'], 11: ['A06', 'T06'],
            12: ['F10', 'S06', 'MANUAL-S01'],
            13: ['A04', 'T04', 'S07'], 14: ['A04', 'T04', 'S09'],
            15: ['A08', 'T08', 'F27', 'S10', 'MANUAL-M03'],
        }[num]
        result.append({**case, 'title': case['id'], 'status': 'PASS' if case['passed'] else 'FAIL',
                       'requirement_ids': sorted(set(tags)), 'source_ids': ['iteration'],
                       'coverage_level': 'synthetic_contract'})
    return result


def run_regressions(output):
    require_assertions_enabled()
    result = []
    for package, tags in [('manual_station', ['MANUAL-M01', 'MANUAL-M02', 'MANUAL-M03', 'MANUAL-M04', 'MANUAL-M05', 'MANUAL-D01']),
                          ('autonomy_lab', ['A05', 'A09', 'T05', 'T09', 'G7']),
                          ('integration_contracts', ['A01', 'A04', 'A08', 'T01', 'T04', 'T08'])]:
        test_dir = ROOT / package / 'tests'
        row = {'id': 'REGRESSION-' + package, 'title': package + ' existing unittest suite',
               'requirement_ids': tags, 'source_ids': [package], 'coverage_level': 'existing_mock_regression'}
        if not test_dir.exists():
            result.append({**row, 'status': 'NOT_EVALUATED', 'passed': None,
                           'evidence': {'reason': 'Package/test directory absent; PR1 and PR2 remain separate',
                                        'tests_run': 0, 'tests_skipped': 0, 'tests_executed': 0}})
            continue
        command = [sys.executable, '-m', 'unittest', 'discover', '-s', str(test_dir), '-v']
        try:
            completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                                       encoding='utf-8', errors='replace', timeout=180)
            log = completed.stdout + completed.stderr
            (output / f'regression_{package}.log').write_text(log, encoding='utf-8')
            summary = summarize_unittest(log, completed.returncode)
            result.append({**row, 'status': summary['status'], 'passed': summary['passed'],
                           'evidence': {'command': command, 'exit_code': completed.returncode,
                                        **{key: summary[key] for key in ('tests_run', 'tests_skipped', 'tests_executed', 'reason')},
                                        'log': f'regression_{package}.log', 'summary': log.splitlines()[-5:],
                                        'scope': 'Mock/offline tests only; skipped tests remain skipped'}})
        except subprocess.TimeoutExpired:
            result.append({**row, 'status': 'FAIL', 'passed': False,
                           'evidence': {'reason': 'test timeout', 'tests_run': None,
                                        'tests_skipped': None, 'tests_executed': None}})
    return result


def write_report(output, report):
    (output / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    lines = ['# 팀 통합 오프라인 시험 결과', '',
             f"상태: {report['status']} · hardware_accessed=false · actual_motion_permission=false", '',
             'PASS는 해당 사례의 기대 동작만 확인합니다. 요구사항 전체·실물 안전성·자율운반 완료를 뜻하지 않습니다.', '',
             '## 실행 결과', '', '| 판정 | 사례 수 |', '|---|---:|']
    lines += [f'| {name} | {report["counts"].get(name, 0)} |' for name in ('PASS', 'FAIL', 'CONTRACT_CONFLICT', 'NOT_EVALUATED')]
    lines += ['', '## 발견사항', '']
    for c in report['cases']:
        if c['status'] != 'PASS':
            lines.append(f"- **{c['id']} · {c['status']}**: {c.get('title', '')}. {json.dumps(c.get('evidence', {}), ensure_ascii=False)}")
    lines += ['', '## 요구사항 추적', '',
              '등록된 모든 ID를 아래에 표시합니다. 시험이 연결되지 않은 요구도 생략하지 않습니다. 전체 세부 조항은 data/requirements.json의 원문 3개에 보존됩니다.', '',
              '| ID | 요구 | 부분 증거 상태 | 사례 |', '|---|---|---|---|']
    for item in report['coverage']:
        lines.append('| ' + ' | '.join([item['id'], item['title'].replace('|', '/'), item['coverage_status'], ', '.join(item['case_ids']) or '없음']) + ' |')
    lines += ['', '실물 G2/G3/G5/G6/G8/G9는 미평가입니다. G7은 규칙 기준기 대비 개선까지 입증해야 하며 시험 실행만으로 통과하지 않습니다.',
              '센서 영상 인식·실측 보정·리프트 물리·적재 안정성·복합 고장 동역학은 구현/계측이 남아 있습니다.',
              '예상된 원문 계약 충돌도 종료코드 2로 보고하며 자동 수정하거나 실물 출력으로 연결하지 않습니다.', '']
    (output / 'REPORT.md').write_text('\n'.join(lines), encoding='utf-8')


def main(argv=None):
    require_assertions_enabled()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite', choices=('contracts', 'team', 'rl', 'all'), default='all')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--notion-source-root', type=Path)
    parser.add_argument('--notion-pack', type=Path, help='private JSON pack downloaded from the shared Notion page')
    args = parser.parse_args(argv)
    output = args.output or ROOT / 'outputs' / ('team_testbed_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    output = output.resolve()
    if (output / 'report.json').exists():
        parser.error('This output already has a report. Choose a new output directory to preserve evidence.')
    output.mkdir(parents=True, exist_ok=True)
    registry = load_registry()
    before = snapshot_preserved_sources()
    cases = []
    if args.notion_pack:
        from .source_pack import import_source_pack
        args.notion_source_root = import_source_pack(args.notion_pack, args.notion_source_root or output / 'private_sources')
    if args.suite in ('contracts', 'all'):
        from .domain_checks import run_domain_checks
        cases.extend(run_domain_checks())
        cases.extend(observation_cases())
        cases.extend(run_regressions(output))
    if args.suite in ('team', 'all'):
        from .team_adapters import run_team_checks
        from .notion_adapters import run_notion_checks
        cases.extend(run_team_checks())
        cases.extend(run_notion_checks(args.notion_source_root))
    if args.suite in ('rl', 'all'):
        from .rl_checks import run_rl_checks
        cases.extend(run_rl_checks(output / 'rl_study'))
    after = snapshot_preserved_sources()
    cases.append(source_preservation_case(before, after))
    coverage = trace_requirements(registry, cases)
    counts = dict(Counter(c['status'] for c in cases))
    failed = counts.get('FAIL', 0)
    findings = counts.get('CONTRACT_CONFLICT', 0) or counts.get('NOT_EVALUATED', 0)
    status = 'FAILED' if failed else 'COMPLETED_WITH_FINDINGS' if findings else 'NAMED_CHECKS_PASSED'
    report = {'schema_version': 1, 'status': status, 'created_utc': datetime.now(timezone.utc).isoformat(),
              'suite': args.suite, 'mode': 'offline', 'hardware_accessed': False, 'actual_motion_permission': False,
              'scope_basis': 'Reviewed Python call paths, fixed-hash source adapters and synthetic inputs; not a hardware isolation certification.',
              'environment': {'python': sys.version, 'platform': platform.platform()},
              'counts': counts, 'cases': cases, 'coverage': coverage,
              'coverage_summary': dict(Counter(c['coverage_status'] for c in coverage)),
              'source_registry_sha256': sha256(Path(__file__).with_name('data') / 'requirements.json'),
              'registry_file_sha256': registry['registry_file_sha256'],
              'full_acceptance_verified': False}
    write_report(output, report)
    print(json.dumps({'status': status, 'counts': counts, 'requirements': len(coverage),
                      'report': str(output / 'REPORT.md'), 'hardware_accessed': False}, ensure_ascii=False), flush=True)
    return 1 if failed else 2 if findings else 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        raise SystemExit(1)
