"""Maintainer utility: freeze the complete work orders plus explicit requirement rows."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def build():
    documents, requirements = [], []
    inputs = [('manual', 'manual_station/WORK_ORDER.md'),
              ('integration', 'docs/autonomy_integration_work_order_20261121.md'),
              ('iteration', 'docs/autonomy_iteration_work_order_20261121.md')]
    for name, filename in inputs:
        path = ROOT / filename
        if name == 'manual':
            path = ROOT / 'team_testbed/data/workorder_sources/manual_work_order_public.md'
        raw = path.read_bytes()
        body = raw.decode('utf-8-sig')
        documents.append({'id': name, 'path': filename, 'sha256': hashlib.sha256(raw).hexdigest(),
                          'text': body, 'scope': 'complete supplied work order, including unnumbered clauses'})
        if name == 'manual':
            documents[-1]['source_edition'] = 'Previously published PR1 edition: personal device address/login omitted; engineering clauses retained.'
            documents[-1]['source_url'] = 'https://github.com/leejunhee0813/forklift/blob/codex/manual-station/manual_station/WORK_ORDER.md'
        if name != 'iteration':
            for line in body.splitlines():
                cells = [v.strip() for v in line.strip().strip('|').split('|')]
                if not line.startswith('|') or not re.match(r'^(?:[AMSPNLD]\d{2}|F\d{2}|G\d)(?:\s|$)', cells[0]):
                    continue
                local_id = cells[0].split()[0]
                ident = 'MANUAL-' + local_id if name == 'manual' else local_id
                requirements.append({'id': ident, 'title': cells[1], 'acceptance': ' | '.join(cells[2:]),
                                     'source_ids': [name], 'source_path': filename,
                                     'source_clause': line, 'physical_validation_required': True})
        else:
            for line in body.splitlines():
                cells = [v.strip() for v in line.strip().strip('|').split('|')]
                if line.startswith('|') and re.fullmatch(r'S\d{2}', cells[0]):
                    requirements.append({'id': cells[0], 'title': cells[1], 'acceptance': ' | '.join(cells[2:]),
                                         'source_ids': [name], 'source_path': filename, 'source_clause': line,
                                         'physical_validation_required': True})
            for match in re.finditer(r'### (A\d{2})[^\n]*\n(.*?)(?=\n### |\n## |\Z)', body, re.S):
                ident, section = match.groups()
                next(r for r in requirements if r['id'] == ident)['detailed_acceptance'] = section.strip()
                test = 'T' + ident[1:]
                requirements.append({'id': test, 'title': ident + ' 인수 시험 묶음', 'acceptance': section.strip(),
                                     'source_ids': [name], 'source_path': filename,
                                     'physical_validation_required': True})
    result = {'schema_version': 1, 'snapshot_date': '2026-11-21',
              'statement': 'Full document text retained. Linked examples are partial evidence, never full acceptance.',
              'documents': documents, 'requirements': requirements}
    path = ROOT / 'team_testbed/data/requirements.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'{len(requirements)} explicit requirements; {len(documents)} complete work orders')


if __name__ == '__main__':
    build()
