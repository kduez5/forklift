"""Offline, source-linked integration tests; never a hardware controller."""

