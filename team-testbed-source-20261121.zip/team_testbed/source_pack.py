"""Import exactly the two reviewed private sources from the team's Notion pack."""
import hashlib
import json
from pathlib import Path

from .notion_adapters import SOURCE_SPECS


def import_source_pack(pack, destination):
    with Path(pack).open('rb') as stream:
        raw = stream.read(200 * 1024 + 1)
    if len(raw) > 200 * 1024:
        raise ValueError('Source pack exceeds 200 KiB')

    def unique(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError('Duplicate JSON key')
            obj[key] = value
        return obj

    def invalid_constant(value):
        raise ValueError('Nonfinite JSON constant: ' + value)

    value = json.loads(raw, object_pairs_hook=unique, parse_constant=invalid_constant)
    if (not isinstance(value, dict) or type(value.get('schema_version')) is not int
            or value['schema_version'] != 1 or value.get('hardware_execution') is not False):
        raise ValueError('Invalid source pack header')
    expected = {s['filename']: s for s in SOURCE_SPECS.values()}
    entries = value.get('files', [])
    if not isinstance(entries, list) or len(entries) != len(expected):
        raise ValueError('Pack must contain exactly the reviewed files')
    validated = {}
    for item in entries:
        if (not isinstance(item, dict) or not all(isinstance(item.get(key), str)
                for key in ('filename', 'text', 'sha256'))):
            raise ValueError('Every source needs string filename, text and sha256')
        name = item['filename']
        if name not in expected or name in validated or Path(name).name != name:
            raise ValueError('Unreviewed, duplicate, or unsafe filename')
        data = item['text'].encode('utf-8')
        digest = hashlib.sha256(data).hexdigest()
        if digest != expected[name]['sha256'] or item['sha256'] != digest:
            raise ValueError('Source pack hash does not match reviewed source')
        validated[name] = data
    destination = Path(destination)
    if any(path.is_symlink() for path in (destination, *destination.parents)):
        raise ValueError('Symlink destination is not accepted')
    destination.mkdir(parents=True, exist_ok=True)
    for name in validated:
        target = destination / name
        if (target.is_symlink() or (target.exists() and not target.is_file())
                or (target.exists() and target.read_bytes() != validated[name])):
            raise ValueError('Existing source differs; choose a new source directory')
    for name, data in validated.items():
        (destination / name).write_bytes(data)
    return destination

