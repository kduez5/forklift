# 팀 통합 오프라인 시험 소스

새 폴더에 압축을 풀고 그 폴더에서 실행하세요.

```powershell
python -m pip install numpy==2.3.1
python -m team_testbed --suite all
```

상세 안내: [team_testbed/README.md](team_testbed/README.md)

프롬프트: [team_testbed/GOAL_PROMPT.md](team_testbed/GOAL_PROMPT.md)

Notion 두 원문은 공유 페이지의 source_pack.json을 별도로 받아 --notion-pack 인수로 지정하세요. 이 ZIP에 비공개 Notion 코드·실제 영상·장치 인증은 없습니다. 충전 중 실물 구동 금지입니다.
