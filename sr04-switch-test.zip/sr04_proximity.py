"""Raspberry Pi 5에서 HC-SR04 4개와 누름 스위치 1개를 테스트한다."""

import time
from datetime import timedelta
from pathlib import Path

import gpiod
from gpiod.line import Bias, Direction, Edge, Value


# (표시 이름, TRIG의 BCM 번호, ECHO의 BCM 번호)
SENSORS = (
    ("1번센서", 16, 12),  # 물리 핀 36, 32
    ("2번센서", 20, 21),  # 물리 핀 38, 40
    ("3번센서", 8, 7),    # 물리 핀 24, 26
    ("4번센서", 25, 24),  # 물리 핀 22, 18
)
THRESHOLD_CM = 10.0
SWITCH = 14  # 물리 핀 8. 누르면 GND와 연결되는 스위치.


def find_gpiochip():
    for path in sorted(Path("/dev").glob("gpiochip[0-9]*")):
        try:
            with gpiod.Chip(str(path)) as chip:
                if chip.get_info().label == "pinctrl-rp1":
                    return str(path)
        except PermissionError:
            continue
    raise RuntimeError("Pi 5의 GPIO 장치를 열 수 없습니다. 장치와 권한을 확인하세요.")


def measure_cm(lines, trig, echo):
    # 이전 측정에서 늦게 도착한 에지를 비운다.
    while lines.wait_edge_events(0):
        lines.read_edge_events()
    if lines.get_value(echo) == Value.ACTIVE:
        return None

    lines.set_value(trig, Value.ACTIVE)
    try:
        time.sleep(0.00001)
    finally:
        lines.set_value(trig, Value.INACTIVE)

    deadline = time.monotonic() + 0.04
    rise_ns = None
    while (remaining := deadline - time.monotonic()) > 0:
        if not lines.wait_edge_events(remaining):
            break
        for event in lines.read_edge_events():
            if event.line_offset != echo:
                continue
            if event.event_type == gpiod.EdgeEvent.Type.RISING_EDGE:
                rise_ns = event.timestamp_ns
            elif rise_ns is not None:
                # 음속 343 m/s를 적용하고 왕복 시간을 편도 거리로 변환한다.
                return (event.timestamp_ns - rise_ns) * 34300 / 2_000_000_000
    return None


def main():
    config = {}
    for _, trig, echo in SENSORS:
        config[trig] = gpiod.LineSettings(direction=Direction.OUTPUT, output_value=Value.INACTIVE)
        config[echo] = gpiod.LineSettings(direction=Direction.INPUT, edge_detection=Edge.BOTH)
    switch_config = gpiod.LineSettings(
        direction=Direction.INPUT, bias=Bias.PULL_UP, active_low=True,
        edge_detection=Edge.BOTH, debounce_period=timedelta(milliseconds=20),
    )
    chip = find_gpiochip()
    # 스위치 이벤트는 별도 큐에 보관해 초음파 에코를 읽는 동안에도 유지한다.
    with (
        gpiod.request_lines(chip, consumer="sr04-proximity", config=config) as lines,
        gpiod.request_lines(chip, consumer="test-switch", config={SWITCH: switch_config}) as switch,
    ):
        pressed = switch.get_value(SWITCH) == Value.ACTIVE
        if pressed:
            print("5번센서 스위치 눌림", flush=True)
        while True:
            for name, trig, echo in SENSORS:
                distance = measure_cm(lines, trig, echo)
                if distance is not None and distance <= THRESHOLD_CM:
                    print(f"{name} 접근", flush=True)
                while switch.wait_edge_events(0):
                    for event in switch.read_edge_events():
                        now_pressed = event.event_type == gpiod.EdgeEvent.Type.RISING_EDGE
                        if now_pressed and not pressed:
                            print("5번센서 스위치 눌림", flush=True)
                        pressed = now_pressed
                # 다음 센서를 울리기 전에 이전 초음파가 사라질 시간을 둔다.
                time.sleep(0.1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except (OSError, RuntimeError) as exc:
        raise SystemExit(str(exc))
